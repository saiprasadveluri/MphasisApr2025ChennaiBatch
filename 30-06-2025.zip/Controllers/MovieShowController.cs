﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your MovieShowDTO is here
using Book.Services; // Assuming your MovieShowService is here


namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/MovieShow
    [ApiController] // Indicates that this is an API controller
    public class MovieShowController : ControllerBase
    {
        private readonly MovieShowService _movieShowService;

        // Constructor for dependency injection
        public MovieShowController(MovieShowService movieShowService)
        {
            _movieShowService = movieShowService;
        }

        
        [HttpGet]

        public async Task<ActionResult<List<MovieShowDTO>>> GetAllMovieShows()
        {
            try
            {
                var movieShows = await _movieShowService.GetAllMovieShowsIdOnly();
                return Ok(movieShows); // Returns 200 OK with the list of movie shows
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving movie shows: {ex.Message}");
            }
        }

        [HttpGet("{id}")] 
        public async Task<ActionResult<MovieShowDTO>> GetMovieShowById(int id)
        {
            try
            {
                var movieShow = await _movieShowService.GetMovieShowIdOnlyById(id);

                if (movieShow == null)
                {
                    return NotFound($"Movie Show with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(movieShow); // Returns 200 OK with the movie show details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the movie show: {ex.Message}");
            }
        }

        [HttpGet("ByMovie/{movieId}")] // Route: /api/MovieShow/ByMovie/{movieId}
        public async Task<ActionResult<List<MovieShowDTO>>> GetMovieShowsByMovieId(int movieId)
        {
            try
            {
                var movieShows = await _movieShowService.GetMovieShowsIdOnlyByMovieId(movieId);
                return Ok(movieShows); // Returns 200 OK with the list of movie shows for the given movie
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving movie shows for movie ID {movieId}: {ex.Message}");
            }
        }

        
        [HttpGet("ByShow/{showId}")] // Route: /api/MovieShow/ByShow/{showId}
        public async Task<ActionResult<List<MovieShowDTO>>> GetMovieShowsByShowId(int showId)
        {
            try
            {
                var movieShows = await _movieShowService.GetMovieShowsIdOnlyByShowId(showId);
                return Ok(movieShows); // Returns 200 OK with the list of movie shows for the given show
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving movie shows for show ID {showId}: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<ActionResult<MovieShowDTO>> AddMovieShow( MovieShowDTO movieShowDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdMovieShow = await _movieShowService.AddMovieShow(movieShowDto);

                return CreatedAtAction(
                    nameof(GetMovieShowById), // Point to the GetMovieShowById endpoint
                    new { id = createdMovieShow.MovieShowId }, // Route value for the new resource's ID
                    createdMovieShow); // The created MovieShowDTO in the response body
            }
            catch (ArgumentNullException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for null DTO
            }
            catch (InvalidOperationException ex)
            {
                // This will catch specific validation errors from the service like "Movie not found", "Show not found", "Theatre not found", or "already exists"
                if (ex.Message.Contains("already exists"))
                {
                    return Conflict(ex.Message); // Returns 409 Conflict for duplicate combination
                }
                return BadRequest(ex.Message); // Returns 400 Bad Request for invalid foreign keys
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the movie show: {ex.Message}"); // Generic 500 for other errors
            }
        }



        [HttpPut("{id}")] // Route: /api/MovieShow/{id
        public async Task<ActionResult<MovieShowDTO>> UpdateMovieShow(int id, MovieShowDTO movieShowDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: Basic ID consistency check if MovieShowId is also in the DTO
            if (movieShowDto.MovieShowId != 0 && movieShowDto.MovieShowId != id)
            {
                return BadRequest("Movie Show ID in the URL does not match the ID in the request body (if provided).");
            }
            movieShowDto.MovieShowId = id; // Ensure the DTO ID matches the route ID

            try
            {
                var updatedMovieShow = await _movieShowService.UpdateMovieShow(id, movieShowDto);

                if (updatedMovieShow == null)
                {
                    return NotFound($"Movie Show with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedMovieShow); // Returns 200 OK with the updated movie show
            }
            catch (ArgumentNullException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for null DTO
            }
            catch (InvalidOperationException ex)
            {
                // This will catch specific validation errors from the service like "Movie not found", "Show not found", "Theatre not found", or "already exists"
                if (ex.Message.Contains("already exists"))
                {
                    return Conflict(ex.Message); // Returns 409 Conflict for duplicate combination
                }
                return BadRequest(ex.Message); // Returns 400 Bad Request for invalid foreign keys
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the movie show: {ex.Message}"); // Generic 500
            }
        }

        [HttpDelete("{id}")] // Route: /api/MovieShow/{id}
        public async Task<ActionResult> DeleteMovieShow(int id)
        {
            try
            {
                var success = await _movieShowService.DeleteMovieShow(id);

                if (!success)
                {
                    return NotFound($"Movie Show with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (InvalidOperationException ex)
            {
                // Catches the "Cannot delete MovieShow as it has associated bookings" error from the service
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the movie show: {ex.Message}");
            }
        }
    }
}
