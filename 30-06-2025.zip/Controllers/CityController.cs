﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your CityDTO is here
using Book.Services; // Assuming your CityService is here
using System.Collections.Generic;
using System.Threading.Tasks;
using System; // For ArgumentException, InvalidOperationException, Exception

namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/City
    [ApiController] // Indicates that this is an API controller
    public class CityController : ControllerBase
    {
        private readonly CityService _cityService;

        // Constructor for dependency injection
        public CityController(CityService cityService)
        {
            _cityService = cityService;
        }

        [HttpGet]
        public async Task<ActionResult<List<CityDTO>>> GetAllCities()
        {
            try
            {
                var cities = await _cityService.GetAllCities();
                return Ok(cities); // Returns 200 OK with the list of cities
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving cities: {ex.Message}");
            }
        }

    
        [HttpGet("{id}")] // Route: /api/City/{id}
       
        public async Task<ActionResult<CityDTO>> GetCityById(int id)
        {
            try
            {
                var city = await _cityService.GetCityById(id);

                if (city == null)
                {
                    return NotFound($"City with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(city); // Returns 200 OK with the city details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the city: {ex.Message}");
            }
        }

        [HttpPost]
  
        public async Task<ActionResult<CityDTO>> AddCity(CityDTO cityDto) // Using CityDTO as per your service
        {
            // Model validation based on attributes in CityDTO (if any)
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdCity = await _cityService.AddCity(cityDto); // Pass the DTO directly

                if (createdCity == null)
                {
                    // This might occur if service returns null for an unspecified reason not caught by exceptions
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create city due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetCityById), // Point to the GetCityById endpoint
                    new { id = createdCity.CityId }, // Route value for the new resource's ID
                    createdCity); // The created CityDTO in the response body
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for validation errors from service
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message); // Returns 409 Conflict if city name already exists
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the city: {ex.Message}"); // Generic 500 for other errors
            }
        }

        
        [HttpPut("{id}")] // Route: /api/City/{id}
       
        public async Task<ActionResult<CityDTO>> UpdateCity(int id, [FromBody] CityDTO cityDto) // Using CityDTO as per your service
        {
            // Model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: Basic ID consistency check if CityId is also in the DTO (though service handles the primary check)
            if (cityDto.CityId != 0 && cityDto.CityId != id) // If CityId is provided in DTO, it should match route ID
            {
                return BadRequest("City ID in the URL does not match the ID in the request body (if provided).");
            }
            // Set DTO ID to route ID for consistency if client didn't provide it or it's 0
            cityDto.CityId = id;


            try
            {
                var updatedCity = await _cityService.UpdateCity(id, cityDto); // Pass ID and DTO

                if (updatedCity == null)
                {
                    return NotFound($"City with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedCity); // Returns 200 OK with the updated city
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for validation errors from service
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message); // Returns 409 Conflict if city name already taken
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the city: {ex.Message}"); // Generic 500
            }
        }

       
        [HttpDelete("{id}")] // Route: /api/City/{id}
        
        public async Task<ActionResult> DeleteCity(int id)
        {
            try
            {
                var success = await _cityService.DeleteCity(id); // Call the service method

                if (!success)
                {
                    return NotFound($"City with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the city: {ex.Message}");
            }
        }
    }
}