﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your GenreDTO is here
using Book.Services; // Assuming your GenreService is here

namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/Genre
    [ApiController] // Indicates that this is an API controller
    public class GenreController : ControllerBase
    {
        private readonly GenreService _genreService;

        // Constructor for dependency injection
        public GenreController(GenreService genreService)
        {
            _genreService = genreService;
        }


        [HttpGet]

        public async Task<ActionResult<List<GenreDTO>>> GetAllGenres()
        {
            try
            {
                var genres = await _genreService.GetAllGenres();
                return Ok(genres); // Returns 200 OK with the list of genres
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving genres: {ex.Message}");
            }
        }

        [HttpGet("{id}")] // Route: /api/Genre/{id}

        public async Task<ActionResult<GenreDTO>> GetGenreById(int id)
        {
            try
            {
                var genre = await _genreService.GetGenreById(id);

                if (genre == null)
                {
                    return NotFound($"Genre with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(genre); // Returns 200 OK with the genre details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the genre: {ex.Message}");
            }
        }

        
        [HttpPost]
        public async Task<ActionResult<GenreDTO>> Add( GenreDTO genreDto) // Using GenreDTO as per your service
        {
            // Model validation based on attributes in GenreDTO (if any, e.g., [Required])
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdGenre = await _genreService.Add(genreDto); // Pass the DTO directly

                if (createdGenre == null)
                {
                    // This might occur if service returns null for an unspecified reason not caught by exceptions
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create genre due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetGenreById), // Point to the GetGenreById endpoint
                    new { id = createdGenre.GenreId }, // Route value for the new resource's ID
                    createdGenre); // The created GenreDTO in the response body
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for validation errors from service
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message); // Returns 409 Conflict if genre name already exists
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the genre: {ex.Message}"); // Generic 500 for other errors
            }
        }

        
        [HttpPut("{id}")] // Route: /api/Genre/{id}
        public async Task<ActionResult<GenreDTO>> UpdateGenre(int id, [FromBody] GenreDTO genreDto) // Using GenreDTO as per your service
        {
            // Model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: Basic ID consistency check if GenreId is also in the DTO (though service handles the primary check)
            if (genreDto.GenreId != 0 && genreDto.GenreId != id) // If GenreId is provided in DTO, it should match route ID
            {
                return BadRequest("Genre ID in the URL does not match the ID in the request body (if provided).");
            }
            // Set DTO ID to route ID for consistency if client didn't provide it or it's 0 (important for service logic relying on it)
            // Note: Your service uses 'id' parameter primarily, so this might not be strictly necessary, but good for robustness.
            genreDto.GenreId = id;


            try
            {
                var updatedGenre = await _genreService.UpdateGenre(id, genreDto); // Pass ID and DTO

                if (updatedGenre == null)
                {
                    return NotFound($"Genre with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedGenre); // Returns 200 OK with the updated genre
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for validation errors from service
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message); // Returns 409 Conflict if genre name already taken
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the genre: {ex.Message}"); // Generic 500
            }
        }

        
        [HttpDelete("{id}")] // Route: /api/Genre/{id}
        public async Task<ActionResult> DeleteGenre(int id)
        {
            try
            {
                var success = await _genreService.DeleteGenre(id); // Call the service method

                if (!success)
                {
                    return NotFound($"Genre with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the genre: {ex.Message}");
            }
        }
    }
}