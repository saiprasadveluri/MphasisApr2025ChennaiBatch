﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your TheatreDTO is here
using Book.Services; // Assuming your TheatreService is here

namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/Theatre
    [ApiController] // Indicates that this is an API controller
    public class TheatreController : ControllerBase
    {
        private readonly TheatreService _theatreService;

        public TheatreController(TheatreService theatreService)
        {
            _theatreService = theatreService;
        }
        [HttpGet]
        public async Task<ActionResult<List<TheatreDTO>>> GetAllTheatres()
        {
            try
            {
                var theatres = await _theatreService.GetAllTheatresAsync();
                return Ok(theatres); // Returns 200 OK with the list of theatres
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving theatres: {ex.Message}");
            }
        }


        [HttpGet("{id}")] // Route: /api/Theatre/{id}
        public async Task<ActionResult<TheatreDTO>> GetTheatreById(int id)
        {
            try
            {
                var theatre = await _theatreService.GetTheatreByIdAsync(id);

                if (theatre == null)
                {
                    return NotFound($"Theatre with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(theatre); // Returns 200 OK with the theatre details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the theatre: {ex.Message}");
            }
        }


        [HttpGet("ByCity/{cityId}")] // Route: /api/Theatre/ByCity/{cityId}
        public async Task<ActionResult<List<TheatreDTO>>> GetTheatresByCityId(int cityId)
        {
            try
            {
                var theatres = await _theatreService.GetTheatresByCityIdAsync(cityId);
                return Ok(theatres); // Returns 200 OK with the list of theatres for the given city
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving theatres for city ID {cityId}: {ex.Message}");
            }
        }

        
        [HttpPost]
        public async Task<ActionResult<TheatreDTO>> CreateTheatre([FromBody] TheatreDTO theatreDto)
        {
            // Basic model validation based on DTO attributes (e.g., [Required], [Range])
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdTheatre = await _theatreService.CreateTheatreAsync(theatreDto);

                if (createdTheatre == null)
                {
                    // This case might occur if the service returns null for an unspecified reason not caught by explicit exceptions
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create theatre due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetTheatreById), // Point to the GetTheatreById endpoint
                    new { id = createdTheatre.TheatreId }, // Route value for the new resource's ID
                    createdTheatre); // The created TheatreDTO in the response body
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., empty name, invalid CityId)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors, e.g., City not found, duplicate theatre
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the theatre: {ex.Message}"); // Generic 500 for other errors
            }
        }

        [HttpPut("{id}")] // Route: /api/Theatre/{id}
        public async Task<ActionResult<TheatreDTO>> UpdateTheatre(int id, [FromBody] TheatreDTO theatreDto)
        {
            // Basic model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: ID consistency check if TheatreId is also in the DTO
            if (theatreDto.TheatreId != 0 && theatreDto.TheatreId != id)
            {
                return BadRequest("Theatre ID in the URL does not match the ID in the request body (if provided).");
            }
            // Ensure the DTO ID matches the route ID for service consistency if the service relies on it
            theatreDto.TheatreId = id;

            try
            {
                var updatedTheatre = await _theatreService.UpdateTheatreAsync(id, theatreDto);

                if (updatedTheatre == null)
                {
                    return NotFound($"Theatre with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedTheatre); // Returns 200 OK with the updated theatre
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., empty name, invalid CityId for update)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors, e.g., City not found, duplicate theatre after update
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the theatre: {ex.Message}"); // Generic 500
            }
        }

        
        [HttpDelete("{id}")] // Route: /api/Theatre/{id}

        public async Task<ActionResult> DeleteTheatre(int id)
        {
            try
            {
                var success = await _theatreService.DeleteTheatreAsync(id);

                if (!success)
                {
                    return NotFound($"Theatre with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors from the service, like existing shows/seats
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the theatre: {ex.Message}");
            }
        }
    }
}