﻿// Book.Controllers/AdminController.cs (assuming this is your Controllers project)
using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Make sure this namespace matches where your DTOs are defined
using Book.Services; // Make sure this namespace matches where your AdminService is
using System.Collections.Generic;
using System.Threading.Tasks; // Required for async/await

namespace Book.Controllers
{
    [Route("api/[controller]")] // Route will be /api/Admin
    [ApiController] // Indicates that this is an API controller
    public class AdminController : ControllerBase // Use ControllerBase for API controllers
    {
        // Inject AdminService directly, as it's the specific service this controller manages.
        // If you truly want to use a 'Unity' class, you need to ensure it exposes AdminService correctly
        // and handle the injection of Unity itself. For now, direct injection is simpler and more common.
        private readonly AdminService _adminService;

        // Constructor for dependency injection.
        // This expects AdminService to be registered in your DI container (e.g., Program.cs/Startup.cs)
        public AdminController(AdminService adminService) // Changed to inject AdminService directly
        {
            _adminService = adminService;
        }

        // GET: api/Admin
        [HttpGet]
        public async Task<ActionResult<List<AdminDTO>>> GetAllAdmins() // Changed to async Task<ActionResult<List<AdminDTO>>>
        {
            var admins = await _adminService.GetAllAdmins(); // Await the async method call
            return Ok(admins); // Returns 200 OK
        }

        // GET: api/Admin/5
        [HttpGet("{id}")] // Added a route for getting by ID
        public async Task<ActionResult<AdminDTO>> GetAdminById(int id) // Added Get by ID
        {
            var admin = await _adminService.GetAdminById(id); // Await the async method call

            if (admin == null)
            {
                return NotFound($"Admin with ID {id} not found."); // Returns 404 Not Found
            }
            return Ok(admin); // Returns 200 OK
        }


        // POST: api/Admin
        [HttpPost]
        // This method should take AdminCreateDTO, as per your AdminService.CreateAdmin signature.
        public async Task<ActionResult<AdminDTO>> CreateAdmin([FromBody] AdminDTO adminCreateDto) // Changed parameter to AdminCreateDTO and added [FromBody]
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdAdmin = await _adminService.CreateAdmin(adminCreateDto); // Await the async method call
                if (createdAdmin == null)
                {
                    // This might happen if the service returns null for some internal reason not caught by specific exceptions
                    return StatusCode(500, "Failed to create admin due to an unexpected server issue.");
                }
                // Return 201 Created and the location of the new resource
                return CreatedAtAction(nameof(GetAdminById), new { id = createdAdmin.AdminId }, createdAdmin);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for validation errors from service
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message); // Returns 409 Conflict if admin name already exists
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred: {ex.Message}"); // Generic 500 for other errors
            }
        }

        // PUT: api/Admin/5
        [HttpPut("{id}")] // Corrected route to include {id}
        // Method now takes 'id' from route and AdminDTO from body
        public async Task<ActionResult<AdminDTO>> UpdateAdmin(int id, [FromBody] AdminDTO adminUpdateDto) // Changed to async and added 'id' parameter
        {
            // Basic validation: Ensure ID in route matches ID in DTO (if DTO has one)
            // (Your service's UpdateAdmin takes 'id' as a separate param, so this check is good)
            if (adminUpdateDto.AdminId != id)
            {
                return BadRequest("Admin ID in the URL does not match the ID in the request body.");
            }

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                // CORRECTED CALL: Pass both 'id' and 'adminUpdateDto'
                var updatedAdmin = await _adminService.UpdateAdmin(id, adminUpdateDto); // Await the async method call
                if (updatedAdmin == null)
                {
                    return NotFound($"Admin with ID {id} not found or update failed."); // Returns 404 Not Found
                }
                return Ok(updatedAdmin); // Returns 200 OK
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for validation errors from service
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message); // Returns 409 Conflict if admin name is taken by another admin
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An unexpected error occurred: {ex.Message}"); // Generic 500
            }
        }

        // DELETE: api/Admin/5
        [HttpDelete("{id}")] // Added a DELETE endpoint
        public async Task<ActionResult> DeleteAdmin(int id)
        {
            var success = await _adminService.DeleteAdmin(id); // Await the async method call
            if (!success)
            {
                return NotFound($"Admin with ID {id} not found."); // Returns 404 Not Found
            }
            return NoContent(); // Returns 204 No Content for successful deletion
        }

        // POST: api/Admin/login
        [HttpPost("login")] // Specific route for login
        public async Task<ActionResult<AdminDTO>> Login([FromBody] AdminDTO adminLoginDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var admin = await _adminService.VerifyAdminCredentials(adminLoginDto.AdminName, adminLoginDto.Password);
                if (admin == null)
                {
                    return Unauthorized("Invalid credentials."); // Returns 401 Unauthorized
                }
                // In a real application, you'd generate and return a JWT token here.
                return Ok(new { Message = "Login successful!", Admin = admin }); // Returns 200 OK
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred during login: {ex.Message}");
            }
        }
    }
}