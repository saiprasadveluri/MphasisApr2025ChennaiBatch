﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your MovieDTO is here
using Book.Services; // Assuming your MovieService is here

namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/Movie
    [ApiController] // Indicates that this is an API controller
    public class MovieController : ControllerBase
    {
        private readonly MovieService _movieService;

        // Constructor for dependency injection
        public MovieController(MovieService movieService)
        {
            _movieService = movieService;
        }


        [HttpGet]
        public async Task<ActionResult<List<MovieDTO>>> GetAllMovies()
        {
            try
            {
                var movies = await _movieService.GetAllMovies();
                return Ok(movies); // Returns 200 OK with the list of movies
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving movies: {ex.Message}");
            }
        }

        [HttpGet("{id}")] // Route: /api/Movie/{id}

        public async Task<ActionResult<MovieDTO>> GetMovieById(int id)
        {
            try
            {
                var movie = await _movieService.GetMovieById(id);

                if (movie == null)
                {
                    return NotFound($"Movie with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(movie); // Returns 200 OK with the movie details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the movie: {ex.Message}");
            }
        }

        [HttpPost]

        public async Task<ActionResult<MovieDTO>> Add([FromBody] MovieDTO movieDto) // Using MovieDTO as per your service
        {
            // Model validation based on attributes in MovieDTO (if any, e.g., [Required])
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdMovie = await _movieService.Add(movieDto); // Pass the DTO directly

                if (createdMovie == null)
                {
                    // This might occur if service returns null for an unspecified reason not caught by exceptions
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create movie due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetMovieById), // Point to the GetMovieById endpoint
                    new { id = createdMovie.MovieId }, // Route value for the new resource's ID
                    createdMovie); // The created MovieDTO in the response body
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors like empty title, invalid GenreId, or non-existent GenreId from the service
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the movie: {ex.Message}"); // Generic 500 for other errors
            }
        }

        [HttpPut("{id}")] // Route: /api/Movie/{id}
        public async Task<ActionResult<MovieDTO>> UpdateMovie(int id, [FromBody] MovieDTO movieDto) // Using MovieDTO as per your service
        {
            // Model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: Basic ID consistency check if MovieId is also in the DTO (though service handles the primary check)
            if (movieDto.MovieId != 0 && movieDto.MovieId != id) // If MovieId is provided in DTO, it should match route ID
            {
                return BadRequest("Movie ID in the URL does not match the ID in the request body (if provided).");
            }
            // Set DTO ID to route ID for consistency if client didn't provide it or it's 0
            movieDto.MovieId = id;


            try
            {
                var updatedMovie = await _movieService.UpdateMovie(id, movieDto); // Pass ID and DTO

                if (updatedMovie == null)
                {
                    return NotFound($"Movie with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedMovie); // Returns 200 OK with the updated movie
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors like empty title, invalid GenreId, or non-existent GenreId from the service
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the movie: {ex.Message}"); // Generic 500
            }
        }

        [HttpDelete("{id}")] // Route: /api/Movie/{id}

        public async Task<ActionResult> DeleteMovie(int id)
        {
            try
            {
                var success = await _movieService.DeleteMovie(id); // Call the service method

                if (!success)
                {
                    return NotFound($"Movie with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the movie: {ex.Message}");
            }
        }
    }
}