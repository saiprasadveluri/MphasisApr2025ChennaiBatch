﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your UserDTO, RegisterDTO, LoginDTO, ChangePasswordDTO are here
using Book.Services; // Assuming your UserService is here

namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/User
    [ApiController] // Indicates that this is an API controller
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;

        public UserController(UserService userService)
        {
            _userService = userService;
        }

        [HttpGet]
        public async Task<ActionResult<List<UserDTO>>> GetAllUsers()
        {
            try
            {
                var users = await _userService.GetAllUsersAsync();
                return Ok(users); // Returns 200 OK with the list of users
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving users: {ex.Message}");
            }
        }

        [HttpGet("{id}")] // Route: /api/User/{id}
        public async Task<ActionResult<UserDTO>> GetUserById(int id)
        {
            try
            {
                var user = await _userService.GetUserByIdAsync(id);

                if (user == null)
                {
                    return NotFound($"User with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(user); // Returns 200 OK with the user details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the user: {ex.Message}");
            }
        }

        [HttpGet("ByEmail")] // Route: /api/User/ByEmail

        public async Task<ActionResult<UserDTO>> GetUserByEmail([FromQuery] string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return BadRequest("Email cannot be empty.");
            }

            try
            {
                var user = await _userService.GetUserByEmailAsync(email);

                if (user == null)
                {
                    return NotFound($"User with email '{email}' not found."); // Returns 404 Not Found
                }
                return Ok(user); // Returns 200 OK with the user details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the user by email: {ex.Message}");
            }
        }


      
        [HttpPost("Register")] // Route: /api/User/Register
        public async Task<ActionResult<UserDTO>> RegisterUser([FromBody] UserDTO userRegisterDto)
        {
            // Basic model validation based on DTO attributes (e.g., [Required], [EmailAddress])
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdUser = await _userService.CreateUserAsync(userRegisterDto);

                if (createdUser == null)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to register user due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetUserById), // Point to the GetUserById endpoint
                    new { id = createdUser.UserId }, // Route value for the new resource's ID
                    createdUser); // The created UserDTO in the response body
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., empty fields, weak password, invalid age)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors, e.g., email already exists
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while registering the user: {ex.Message}"); // Generic 500 for other errors
            }
        }


        [HttpPost("Login")] // Route: /api/User/Login
        public async Task<ActionResult<UserDTO>> Login([FromBody] LoginDTO loginDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (string.IsNullOrWhiteSpace(loginDto.UserEmail) || string.IsNullOrWhiteSpace(loginDto.Password))
            {
                return BadRequest("Email and Password are required.");
            }

            try
            {
                var user = await _userService.VerifyUserCredentialsAsync(loginDto.UserEmail, loginDto.Password);

                if (user == null)
                {
                    return Unauthorized("Invalid email or password."); // Returns 401 Unauthorized
                }

                return Ok(user); // Returns 200 OK with the authenticated user's DTO
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred during login: {ex.Message}");
            }
        }
        [HttpPut("{id}")] // Route: /api/User/{id}

        public async Task<ActionResult<UserDTO>> UpdateUser(int id, [FromBody] UserDTO userUpdateDto)
        {
            // Basic model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: ID consistency check if UserId is also in the DTO
            if (userUpdateDto.UserId != 0 && userUpdateDto.UserId != id)
            {
                return BadRequest("User ID in the URL does not match the ID in the request body (if provided).");
            }
            // Ensure the DTO ID matches the route ID for service consistency if the service relies on it
            userUpdateDto.UserId = id;

            try
            {
                var updatedUser = await _userService.UpdateUserAsync(id, userUpdateDto);

                if (updatedUser == null)
                {
                    return NotFound($"User with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedUser); // Returns 200 OK with the updated user
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., empty fields, invalid age for update)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors, e.g., email already taken by another user
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the user: {ex.Message}"); // Generic 500
            }
        }

     
        [HttpPut("ChangePassword/{id}")] // Route: /api/User/ChangePassword/{id}

        public async Task<ActionResult> ChangePassword(int id, [FromBody] ChangePasswordDTO changePasswordDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var success = await _userService.ChangePasswordAsync(id, changePasswordDto);

                if (!success)
                {
                    return NotFound($"User with ID {id} not found."); // User not found
                }
                return NoContent(); // Returns 204 No Content for successful password change
            }
            catch (UnauthorizedAccessException ex)
            {
                return Unauthorized(ex.Message); // Returns 401 Unauthorized for incorrect current password
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for invalid new password
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while changing password: {ex.Message}");
            }
        }


        
        [HttpDelete("{id}")] // Route: /api/User/{id}

        public async Task<ActionResult> DeleteUser(int id)
        {
            try
            {
                var success = await _userService.DeleteUserAsync(id);

                if (!success)
                {
                    return NotFound($"User with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors from the service, e.g., existing bookings/comments
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the user: {ex.Message}");
            }
        }
    }
}