﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your SeatDTO is here
using Book.Services; // Assuming your SeatService is here

namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/Seat
    [ApiController] // Indicates that this is an API controller
    public class SeatController : ControllerBase
    {
        private readonly SeatService _seatService;
        public SeatController(SeatService seatService)
        {
            _seatService = seatService;
        }

        [HttpGet]
        public async Task<ActionResult<List<SeatDTO>>> GetAllSeats()
        {
            try
            {
                var seats = await _seatService.GetAllSeatsAsync();
                return Ok(seats); // Returns 200 OK with the list of seats
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving seats: {ex.Message}");
            }
        }


        [HttpGet("{id}")] // Route: /api/Seat/{id}
        public async Task<ActionResult<SeatDTO>> GetSeatById(int id)
        {
            try
            {
                var seat = await _seatService.GetSeatByIdAsync(id);

                if (seat == null)
                {
                    return NotFound($"Seat with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(seat); // Returns 200 OK with the seat details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the seat: {ex.Message}");
            }
        }


        [HttpGet("ByTheatre/{theatreId}")] // Route: /api/Seat/ByTheatre/{theatreId}
        public async Task<ActionResult<List<SeatDTO>>> GetSeatsByTheatreId(int theatreId)
        {
            try
            {
                var seats = await _seatService.GetSeatsByTheatreIdAsync(theatreId);
                return Ok(seats); // Returns 200 OK with the list of seats for the given theatre
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving seats for theatre ID {theatreId}: {ex.Message}");
            }
        }

       
        [HttpPost]
        public async Task<ActionResult<SeatDTO>> CreateSeat([FromBody] SeatDTO seatDto)
        {
            // Basic model validation based on DTO attributes (e.g., [Required], [Range])
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdSeat = await _seatService.CreateSeatAsync(seatDto);

                if (createdSeat == null)
                {
                    // This case might occur if the service returns null for an unspecified reason not caught by explicit exceptions
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create seat due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetSeatById), // Point to the GetSeatById endpoint
                    new { id = createdSeat.SeatId }, // Route value for the new resource's ID
                    createdSeat); // The created SeatDTO in the response body
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., invalid TheatreId)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors, e.g., duplicate seat within a theatre
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the seat: {ex.Message}"); // Generic 500 for other errors
            }
        }

        [HttpPut("{id}")] // Route: /api/Seat/{id}
        public async Task<ActionResult<SeatDTO>> UpdateSeat(int id, [FromBody] SeatDTO seatDto)
        {
            // Basic model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: ID consistency check if SeatId is also in the DTO
            if (seatDto.SeatId != 0 && seatDto.SeatId != id)
            {
                return BadRequest("Seat ID in the URL does not match the ID in the request body (if provided).");
            }
            // Ensure the DTO ID matches the route ID for service consistency if the service relies on it
            seatDto.SeatId = id;

            try
            {
                var updatedSeat = await _seatService.UpdateSeatAsync(id, seatDto);

                if (updatedSeat == null)
                {
                    return NotFound($"Seat with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedSeat); // Returns 200 OK with the updated seat
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., invalid TheatreId for update)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors, e.g., duplicate seat within a theatre after update
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the seat: {ex.Message}"); // Generic 500
            }
        }

        [HttpDelete("{id}")] // Route: /api/Seat/{id}
        public async Task<ActionResult> DeleteSeat(int id)
        {
            try
            {
                var success = await _seatService.DeleteSeatAsync(id);

                if (!success)
                {
                    return NotFound($"Seat with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the seat: {ex.Message}");
            }
        }
    }
}