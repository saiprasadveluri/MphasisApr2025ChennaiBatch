﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your TicketDTO is here
using Book.Services; // Assuming your TicketService is here

namespace Book.Controllers
{
    [Route("api/[controller]")] 
    [ApiController] 
    public class TicketController : ControllerBase
    {
        private readonly TicketService _ticketService;

        // Constructor for dependency injection
        public TicketController(TicketService ticketService)
        {
            _ticketService = ticketService;
        }

        [HttpGet]
        public async Task<ActionResult<List<TicketDTO>>> GetAllTickets()
        {
            try
            {
                var tickets = await _ticketService.GetAllTicketsAsync();
                return Ok(tickets); 
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving tickets: {ex.Message}");
            }
        }

        [HttpGet("{id}")] // Route: /api/Ticket/{id}
        public async Task<ActionResult<TicketDTO>> GetTicketById(int id)
        {
            try
            {
                var ticket = await _ticketService.GetTicketByIdAsync(id);

                if (ticket == null)
                {
                    return NotFound($"Ticket with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(ticket); // Returns 200 OK with the ticket details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the ticket: {ex.Message}");
            }
        }

        [HttpGet("ByBooking/{bookingId}")] // Route: /api/Ticket/ByBooking/{bookingId}
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<List<TicketDTO>>> GetTicketsByBookingId(int bookingId)
        {
            try
            {
                var tickets = await _ticketService.GetTicketsByBookingIdAsync(bookingId);
                return Ok(tickets); // Returns 200 OK with the list of tickets for the given booking
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving tickets for booking ID {bookingId}: {ex.Message}");
            }
        }

      
        [HttpPost]
        public async Task<ActionResult<TicketDTO>> CreateTicket([FromQuery] int bookingId, [FromQuery] int seatId)
        {

            try
            {
                var createdTicket = await _ticketService.CreateTicketAsync(bookingId, seatId);

                if (createdTicket == null)
                {
                    // This case might occur if the service returns null for an unspecified reason not caught by explicit exceptions
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create ticket due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetTicketById), // Point to the GetTicketById endpoint
                    new { id = createdTicket.TicketId }, // Route value for the new resource's ID
                    createdTicket); // The created TicketDTO in the response body
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., invalid IDs)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors, e.g., Booking/Seat not found, seat already ticketed
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the ticket: {ex.Message}"); // Generic 500 for other errors
            }
        }

       
        [HttpPut("{id}")] // Route: /api/Ticket/{id}
        public async Task<ActionResult<TicketDTO>> UpdateTicket(int id, [FromBody] TicketDTO ticketDto)
        {
            // Basic model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: ID consistency check if TicketId is also in the DTO
            if (ticketDto.TicketId != 0 && ticketDto.TicketId != id)
            {
                return BadRequest("Ticket ID in the URL does not match the ID in the request body (if provided).");
            }
            // Ensure the DTO ID matches the route ID for service consistency if the service relies on it
            ticketDto.TicketId = id; // This ensures the service updates the correct ticket ID.

            try
            {
                var updatedTicket = await _ticketService.UpdateTicketAsync(id, ticketDto);

                if (updatedTicket == null)
                {
                    return NotFound($"Ticket with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedTicket); // Returns 200 OK with the updated ticket
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., invalid IDs for update)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (InvalidOperationException ex)
            {
                // Catches specific business logic errors, e.g., Booking/Seat not found, seat already ticketed after update
                return Conflict(ex.Message); // Returns 409 Conflict
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the ticket: {ex.Message}"); // Generic 500
            }
        }

        
        [HttpDelete("{id}")] // Route: /api/Ticket/{id}
        public async Task<ActionResult> DeleteTicket(int id)
        {
            try
            {
                var success = await _ticketService.DeleteTicketAsync(id);

                if (!success)
                {
                    return NotFound($"Ticket with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the ticket: {ex.Message}");
            }
        }
    }
}