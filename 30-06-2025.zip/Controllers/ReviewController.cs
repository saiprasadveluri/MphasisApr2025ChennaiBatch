﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your ReviewDTO is here
using Book.Services; // Assuming your ReviewService is here

namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/Review
    [ApiController] // Indicates that this is an API controller
    public class ReviewController : ControllerBase
    {
        private readonly ReviewService _reviewService;
        public ReviewController(ReviewService reviewService)
        {
            _reviewService = reviewService;
        }

        [HttpGet]
        public async Task<ActionResult<List<ReviewDTO>>> GetAllReviews()
        {
            try
            {
                var reviews = await _reviewService.GetAllReviewsAsync();
                return Ok(reviews); // Returns 200 OK with the list of reviews
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving reviews: {ex.Message}");
            }
        }


        [HttpGet("{id}")] // Route: /api/Review/{id}
        public async Task<ActionResult<ReviewDTO>> GetReviewById(int id)
        {
            try
            {
                var review = await _reviewService.GetReviewByIdAsync(id);

                if (review == null)
                {
                    return NotFound($"Review with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(review); // Returns 200 OK with the review details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the review: {ex.Message}");
            }
        }


        [HttpGet("ByMovie/{movieId}")] // Route: /api/Review/ByMovie/{movieId}
        public async Task<ActionResult<List<ReviewDTO>>> GetReviewsByMovieId(int movieId)
        {
            try
            {
                var reviews = await _reviewService.GetReviewsByMovieIdAsync(movieId);
                return Ok(reviews); // Returns 200 OK with the list of reviews for the given movie
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving reviews for movie ID {movieId}: {ex.Message}");
            }
        }

       
        [HttpPost]
        public async Task<ActionResult<ReviewDTO>> CreateReview([FromBody] ReviewDTO reviewDto)
        {
            // Basic model validation based on DTO attributes (e.g., [Required], [Range])
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdReview = await _reviewService.CreateReviewAsync(reviewDto);

                if (createdReview == null)
                {
                    // This case might occur if the service returns null for an unspecified reason not caught by explicit exceptions
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create review due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetReviewById), // Point to the GetReviewById endpoint
                    new { id = createdReview.CommentId }, // Route value for the new resource's ID
                    createdReview); // The created ReviewDTO in the response body
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., invalid rating, non-existent User/Movie IDs)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the review: {ex.Message}"); // Generic 500 for other errors
            }
        }


       
        [HttpPut("{id}")] // Route: /api/Review/{id}
        public async Task<ActionResult<ReviewDTO>> UpdateReview(int id, [FromBody] ReviewDTO reviewDto)
        {
            // Basic model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: ID consistency check if CommentId is also in the DTO
            if (reviewDto.CommentId != 0 && reviewDto.CommentId != id)
            {
                return BadRequest("Comment ID in the URL does not match the ID in the request body (if provided).");
            }
            // Ensure the DTO ID matches the route ID for service consistency if the service relies on it
            reviewDto.CommentId = id;

            try
            {
                var updatedReview = await _reviewService.UpdateReviewAsync(id, reviewDto);

                if (updatedReview == null)
                {
                    return NotFound($"Review with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedReview); // Returns 200 OK with the updated review
            }
            catch (ArgumentException ex)
            {
                // This will catch validation errors from the service (e.g., invalid rating for update)
                return BadRequest(ex.Message); // Returns 400 Bad Request
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the review: {ex.Message}"); // Generic 500
            }
        }

        
        [HttpDelete("{id}")] // Route: /api/Review/{id}
        public async Task<ActionResult> DeleteReview(int id)
        {
            try
            {
                var success = await _reviewService.DeleteReviewAsync(id);

                if (!success)
                {
                    return NotFound($"Review with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the review: {ex.Message}");
            }
        }
    }
}