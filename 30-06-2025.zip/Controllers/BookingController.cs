﻿using Book.DTO;
using Book.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly BookingService _bookingService;

        public BookingController(BookingService bookingService)
        {
            _bookingService = bookingService;
        }
        [HttpGet]
        public async Task<ActionResult<List<BookingDTO>>> GetAllBooking()
        {
            var booking = await _bookingService.GetAllBooking(); // Await the async method call
            return Ok(booking);
        }
        [HttpPost]
        public async Task<ActionResult<BookingDTO>> Add(BookingDTO dto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                // Map DTO to Entity
                var booking = new Booking
                {
                    UserId = dto.UserId,
                    MovieShowId = dto.ShowId,
                    NumberOfTickets = dto.NumberOfTickets,
                    TotalAmount = dto.TotalAmount,
                    BookingDate = dto.BookingDate,
                    Status = dto.Status // Defaulted in DTO, but can be set by client
                };

                var createdBooking = await _bookingService.Add(booking);

                // Map Entity back to DTO for response
                var bookingDto = new BookingDTO
                {
                    BookingId = createdBooking.BookingId,
                    UserId = createdBooking.UserId,
                    ShowId = createdBooking.MovieShowId,
                    NumberOfTickets = createdBooking.NumberOfTickets,
                    TotalAmount = createdBooking.TotalAmount,
                    BookingDate = createdBooking.BookingDate,
                    Status = createdBooking.Status
                };

                // Return 201 Created and the location of the new resource
                // Note: We don't have a GetBookingById yet, so we'll use a placeholder route.
                // If you add GetBookingById, update this.
                return CreatedAtAction(
                    nameof(GetBookingsByUserId), // Assuming GetBookingsByUserId is the closest "get"
                    new { userId = bookingDto.UserId }, // Or specific booking ID if you add GetBookingById
                    bookingDto);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while creating the booking: {ex.Message}");
            }
        }
        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<BookingDTO>>> GetBookingsByUserId(int userId)
        {
            try
            {
                var bookings = await _bookingService.GetBookingsByUserId(userId);
                if (bookings == null)
                {
                    // This might happen if no bookings found, service returns empty list, or null (less ideal)
                    return Ok(new List<BookingDTO>()); // Return empty list if no bookings, not 404
                }

                // Map Entities to DTOs
                var bookingDtos = bookings.Select(b => new BookingDTO
                {
                    BookingId = b.BookingId,
                    UserId = b.UserId,
                    ShowId = b.MovieShowId,
                    NumberOfTickets = b.NumberOfTickets,
                    TotalAmount = b.TotalAmount,
                    BookingDate = b.BookingDate,
                    Status = b.Status
                }).ToList();

                return Ok(bookingDtos); // Returns 200 OK
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving bookings: {ex.Message}");
            }
        }
        [HttpPut("{bookingId}/status")]
        public async Task<ActionResult> UpdateBooking(int bookingId,  BookingDTO statusDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            if (string.IsNullOrWhiteSpace(statusDto.Status))
            {
                return BadRequest("Status cannot be empty.");
            }

            try
            {
                // The service doesn't return a bool or the updated entity, so we check if the booking exists first
                var existingBooking = await _bookingService.GetBookingsByUserId(bookingId); // Assuming you'll add this to BookingService
                if (existingBooking == null)
                {
                    return NotFound($"Booking with ID {bookingId} not found.");
                }

                await _bookingService.UpdateBooking(bookingId, statusDto.Status);
                return NoContent(); // Returns 204 No Content on success
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while updating booking status: {ex.Message}");
            }
        }
        [HttpPut("{bookingId}/reschedule")]
        public async Task<ActionResult> RescheduleBooking(int bookingId, BookingDTO rescheduleDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Basic validation for dates
            if (rescheduleDto.NewDate < DateTime.Today)
            {
                return BadRequest("New date cannot be in the past.");
            }

            try
            {
                // The service doesn't return a bool or the updated entity, so we check if the booking exists first
                var existingBooking = await _bookingService.GetBookingsByUserId(bookingId); // Assuming you'll add this to BookingService
                if (existingBooking == null)
                {
                    return NotFound($"Booking with ID {bookingId} not found.");
                }

                await _bookingService.Reschedule(bookingId, rescheduleDto.NewDate);
                return NoContent(); // Returns 204 No Content on success
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while rescheduling the booking: {ex.Message}");
            }
        }
        [HttpPut("{bookingId}/cancel")]
        public async Task<ActionResult> CancelBooking(int bookingId)
        {
            try
            {
                var success = await _bookingService.CancelBooking(bookingId);
                if (!success)
                {
                    return NotFound($"Booking with ID {bookingId} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful cancellation
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while cancelling the booking: {ex.Message}");
            }
        }
    }
}
