﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO; // Assuming your LanguageDTO is here
using Book.Services; // Assuming your LanguageService is here
using System.Collections.Generic;
using System.Threading.Tasks;
using System; // For ArgumentException, InvalidOperationException, Exception

namespace Book.Controllers
{
    [Route("api/[controller]")] // Base route: /api/Language
    [ApiController] // Indicates that this is an API controller
    public class LanguageController : ControllerBase
    {
        private readonly LanguageService _languageService;


        public LanguageController(LanguageService languageService)
        {
            _languageService = languageService;
        }

        
        [HttpGet]
        public async Task<ActionResult<List<LanguageDTO>>> GetAllLanguages()
        {
            try
            {
                var languages = await _languageService.GetAllLanguages();
                return Ok(languages); // Returns 200 OK with the list of languages
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving languages: {ex.Message}");
            }
        }

      
        [HttpGet("{id}")] // Route: /api/Language/{id}

        public async Task<ActionResult<LanguageDTO>> GetLanguageById(int id)
        {
            try
            {
                var language = await _languageService.GetLanguageById(id);

                if (language == null)
                {
                    return NotFound($"Language with ID {id} not found."); // Returns 404 Not Found
                }
                return Ok(language); // Returns 200 OK with the language details
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while retrieving the language: {ex.Message}");
            }
        }

        [HttpPost]
        public async Task<ActionResult<LanguageDTO>> CreateLanguage([FromBody] LanguageDTO languageDto) // Using LanguageDTO as per your service
        {
            // Model validation based on attributes in LanguageDTO (if any, e.g., [Required])
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Returns 400 Bad Request if DTO validation fails
            }

            try
            {
                var createdLanguage = await _languageService.CreateLanguage(languageDto); // Pass the DTO directly

                if (createdLanguage == null)
                {
                    // This might occur if service returns null for an unspecified reason not caught by exceptions
                    return StatusCode(StatusCodes.Status500InternalServerError, "Failed to create language due to an unexpected server issue.");
                }

                // Return 201 Created and the location of the new resource
                return CreatedAtAction(
                    nameof(GetLanguageById), // Point to the GetLanguageById endpoint
                    new { id = createdLanguage.LanguageId }, // Route value for the new resource's ID
                    createdLanguage); // The created LanguageDTO in the response body
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for validation errors from service
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message); // Returns 409 Conflict if language name already exists
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while creating the language: {ex.Message}"); // Generic 500 for other errors
            }
        }

        [HttpPut("{id}")] // Route: /api/Language/{id}
        public async Task<ActionResult<LanguageDTO>> UpdateLanguage(int id, [FromBody] LanguageDTO languageDto) // Using LanguageDTO as per your service
        {
            // Model validation
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            // Optional: Basic ID consistency check if LanguageId is also in the DTO (though service handles the primary check)
            if (languageDto.LanguageId != 0 && languageDto.LanguageId != id) // If LanguageId is provided in DTO, it should match route ID
            {
                return BadRequest("Language ID in the URL does not match the ID in the request body (if provided).");
            }
            // Set DTO ID to route ID for consistency if client didn't provide it or it's 0 (important for service logic relying on it)
            // Note: Your service uses 'id' parameter primarily, so this might not be strictly necessary, but good for robustness.
            languageDto.LanguageId = id;


            try
            {
                var updatedLanguage = await _languageService.UpdateLanguage(id, languageDto); // Pass ID and DTO

                if (updatedLanguage == null)
                {
                    return NotFound($"Language with ID {id} not found."); // Returns 404 Not Found if service returns null
                }
                return Ok(updatedLanguage); // Returns 200 OK with the updated language
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message); // Returns 400 Bad Request for validation errors from service
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message); // Returns 409 Conflict if language name already taken
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An unexpected error occurred while updating the language: {ex.Message}"); // Generic 500
            }
        }

        
        [HttpDelete("{id}")] 
        public async Task<ActionResult> DeleteLanguage(int id)
        {
            try
            {
                var success = await _languageService.DeleteLanguage(id); // Call the service method

                if (!success)
                {
                    return NotFound($"Language with ID {id} not found."); // Returns 404 Not Found
                }
                return NoContent(); // Returns 204 No Content for successful deletion
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, $"An error occurred while deleting the language: {ex.Message}");
            }
        }
    }
}