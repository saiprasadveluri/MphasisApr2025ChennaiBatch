﻿using Book.Data; // For the Genre entity
using Book.Data.DB; // For BookMyShowDbContext
using Book.DTO; // For GenreDTO, GenreCreateDTO, GenreUpdateDTO
using Microsoft.EntityFrameworkCore; // For ToListAsync, FindAsync, etc.

namespace Book.Services
{
    public class GenreService
    {
        private readonly BookMyShowDbContext _context;

        public GenreService(BookMyShowDbContext context)
        {
            _context = context; // Assign the injected context to the private field
        }

        // ***** Listing all Genres
        public async Task<List<GenreDTO>> GetAllGenres()
        {
            // FIX: Changed 'this.Genres' to '_context.Genres'
            return await _context.Genres
                                 .Select(g => new GenreDTO
                                 {
                                     GenreId = g.GenreId,
                                     GenreName = g.GenreName
                                 })
                                 .ToListAsync();
        }

        // ***** Getting Genre by ID
        public async Task<GenreDTO?> GetGenreById(int id) // Changed return type to GenreDTO? for nullability
        {
            // FIX: Changed 'this.Genres.FindAsync(id)' to '_context.Genres.FindAsync(id)'
            var genre = await _context.Genres.FindAsync(id);

            if (genre == null)
            {
                return null;
            }

            return new GenreDTO
            {
                GenreId = genre.GenreId,
                GenreName = genre.GenreName
            };
        }

        // **** Create new Genre
        public async Task<GenreDTO?> Add(GenreDTO genreCreate) // Changed parameter to GenreCreateDTO and return to GenreDTO?
        {
            if (string.IsNullOrWhiteSpace(genreCreate.GenreName))
            {
                throw new ArgumentException("Genre name cannot be empty or whitespace.", nameof(genreCreate.GenreName));
            }

            // Optional: Check if a genre with the same name already exists
            if (await _context.Genres.AnyAsync(g => g.GenreName == genreCreate.GenreName))
            {
                throw new InvalidOperationException($"Genre with name '{genreCreate.GenreName}' already exists.");
            }

            var genre = new Genre
            {
                GenreName = genreCreate.GenreName
            };

            // FIX: Changed 'this.Genres.Add(genre)' to '_context.Genres.Add(genre)'
            _context.Genres.Add(genre);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new GenreDTO
                {
                    GenreId = genre.GenreId,
                    GenreName = genre.GenreName
                };
            }
            return null;
        }

        // **** Update Genre (Added for completeness, similar to CityService)
        public async Task<GenreDTO?> UpdateGenre(int id, GenreDTO genreUpdate) // Added for completeness
        {
            var existingGenre = await _context.Genres.FindAsync(id);

            if (existingGenre == null)
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(genreUpdate.GenreName))
            {
                throw new ArgumentException("Genre name cannot be empty or whitespace for update.", nameof(genreUpdate.GenreName));
            }

            // Check if updated genre name is already taken by another genre (excluding current genre)
            if (existingGenre.GenreName != genreUpdate.GenreName)
            {
                var nameTaken = await _context.Genres.AnyAsync(g => g.GenreName == genreUpdate.GenreName && g.GenreId != id);
                if (nameTaken)
                {
                    throw new InvalidOperationException($"Genre name '{genreUpdate.GenreName}' is already taken by another genre.");
                }
            }

            existingGenre.GenreName = genreUpdate.GenreName;

            _context.Entry(existingGenre).State = EntityState.Modified;
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new GenreDTO
                {
                    GenreId = existingGenre.GenreId,
                    GenreName = existingGenre.GenreName
                };
            }
            return null;
        }


        // **** Delete Genre
        public async Task<bool> DeleteGenre(int id) // Changed return type to bool
        {
            // FIX: Changed 'this.Genres.FindAsync(id)' to '_context.Genres.FindAsync(id)'
            var genreToDelete = await _context.Genres.FindAsync(id);

            if (genreToDelete == null)
            {
                return false;
            }

            // FIX: Changed 'this.Genres.Remove(genreToDelete)' to '_context.Genres.Remove(genreToDelete)'
            _context.Genres.Remove(genreToDelete);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0;
        }
    }

    // You'll likely need these DTOs in your Book.DTO namespace (e.g., Book.DTO/GenreDTO.cs)
    /*
    namespace Book.DTO
    {
        public class GenreDTO
        {
            public int GenreId { get; set; }
            public string GenreName { get; set; }
        }

        public class GenreCreateDTO
        {
            public string GenreName { get; set; }
        }

        public class GenreUpdateDTO
        {
            public string GenreName { get; set; }
        }
    }
    */
}