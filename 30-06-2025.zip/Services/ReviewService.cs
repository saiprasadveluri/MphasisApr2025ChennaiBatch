﻿using Book.Data; // For the Review entity
using Book.Data.DB; // For BookMyShowDbContext
using Book.DTO; // For ReviewDTO, ReviewCreateDTO, ReviewUpdateDTO (assuming these exist)
using Microsoft.EntityFrameworkCore; // For ToListAsync, FindAsync, etc.
using System.Collections.Generic; // For List<T>
using System.Linq; // For .Select(), .Where()
using System.Threading.Tasks; // For async/await
using System; // For ArgumentException, InvalidOperationException

namespace Book.Services
{
    public class ReviewService
    {
        private readonly BookMyShowDbContext _context; // Injected DbContext

        public ReviewService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<ReviewDTO>> GetAllReviewsAsync()
        {
            // FIX: Changed 'this.Reviews' to '_context.Reviews'
            return await _context.Reviews
                                 .Select(r => new ReviewDTO
                                 {
                                     CommentId = r.CommentId,
                                     Rating = r.Rating,
                                     CommentText = r.CommentText,
                                     DatePosted = r.DatePosted,
                                     UserId = r.UserId,
                                     MovieId = r.MovieId,
                                     Timings = r.Timings // Assuming Timings is part of your Review entity and DTO
                                 })
                                 .ToListAsync();
        }

        public async Task<ReviewDTO?> GetReviewByIdAsync(int id) // Changed return type to ReviewDTO?
        {
            // FIX: Changed 'this.Reviews.FindAsync(id)' to '_context.Reviews.FindAsync(id)'
            var review = await _context.Reviews.FindAsync(id);

            if (review == null)
            {
                return null;
            }

            return new ReviewDTO
            {
                CommentId = review.CommentId,
                Rating = review.Rating,
                CommentText = review.CommentText,
                DatePosted = review.DatePosted,
                UserId = review.UserId,
                MovieId = review.MovieId,
                Timings = review.Timings
            };
        }

        public async Task<List<ReviewDTO>> GetReviewsByMovieIdAsync(int movieId)
        {
            // FIX: Changed 'this.Reviews' to '_context.Reviews'
            return await _context.Reviews
                                 .Where(r => r.MovieId == movieId)
                                 .Select(r => new ReviewDTO
                                 {
                                     CommentId = r.CommentId,
                                     Rating = r.Rating,
                                     CommentText = r.CommentText,
                                     DatePosted = r.DatePosted,
                                     UserId = r.UserId,
                                     MovieId = r.MovieId,
                                     Timings = r.Timings
                                 })
                                 .ToListAsync();
        }

        // ****Create Operation
        public async Task<ReviewDTO?> CreateReviewAsync(ReviewDTO reviewCreate) // Changed parameter to ReviewCreateDTO and return to ReviewDTO?
        {
            // Input validation
            if (reviewCreate.Rating < 1 || reviewCreate.Rating > 5)
            {
                throw new ArgumentException("Rating must be between 1 and 5.", nameof(reviewCreate.Rating));
            }
            if (reviewCreate.UserId <= 0)
            {
                throw new ArgumentException("Invalid UserId.", nameof(reviewCreate.UserId));
            }
            if (reviewCreate.MovieId <= 0)
            {
                throw new ArgumentException("Invalid MovieId.", nameof(reviewCreate.MovieId));
            }
            // Optional: Check if User and Movie actually exist
            var userExists = await _context.Users.AnyAsync(u => u.UserId == reviewCreate.UserId);
            if (!userExists)
            {
                throw new ArgumentException($"User with ID {reviewCreate.UserId} does not exist.", nameof(reviewCreate.UserId));
            }
            var movieExists = await _context.Movies.AnyAsync(m => m.MovieId == reviewCreate.MovieId);
            if (!movieExists)
            {
                throw new ArgumentException($"Movie with ID {reviewCreate.MovieId} does not exist.", nameof(reviewCreate.MovieId));
            }

            var review = new Review
            {
                Rating =(int)reviewCreate.Rating, // No need for explicit cast if Rating is int
                CommentText = reviewCreate.CommentText,
                DatePosted = DateTime.UtcNow, // Set date posted here
                UserId = reviewCreate.UserId,
                MovieId = reviewCreate.MovieId,
                Timings = reviewCreate.Timings // Ensure Timings is provided if it's a required field
            };

            // FIX: Changed 'this.Reviews.Add(review)' to '_context.Reviews.Add(review)'
            _context.Reviews.Add(review);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new ReviewDTO
                {
                    CommentId = review.CommentId, // ID will be populated after SaveChangesAsync
                    Rating = review.Rating,
                    CommentText = review.CommentText,
                    DatePosted = review.DatePosted,
                    UserId = review.UserId,
                    MovieId = review.MovieId,
                    Timings = review.Timings
                };
            }
            return null;
        }

        // ***********Update
        public async Task<ReviewDTO?> UpdateReviewAsync(int id, ReviewDTO reviewUpdate) // Changed parameter to ReviewUpdateDTO and return to ReviewDTO?
        {
            // FIX: Changed 'this.Reviews.FindAsync(id)' to '_context.Reviews.FindAsync(id)'
            var existingReview = await _context.Reviews.FindAsync(id);

            if (existingReview == null)
            {
                return null;
            }

            // Input validation for update
            if (reviewUpdate.Rating < 1 || reviewUpdate.Rating > 5)
            {
                throw new ArgumentException("Rating must be between 1 and 5 for update.", nameof(reviewUpdate.Rating));
            }

            // Update only allowed fields
            existingReview.Rating =(int) reviewUpdate.Rating;
            existingReview.CommentText = reviewUpdate.CommentText;
            existingReview.Timings = reviewUpdate.Timings; // Update Timings if it's an updatable field

            // No need to update UserId or MovieId for an existing review typically,
            // as those form the core identity of the review.

            // FIX: Changed 'this.Entry(existingReview).State' to '_context.Entry(existingReview).State'
            _context.Entry(existingReview).State = EntityState.Modified;
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new ReviewDTO
                {
                    CommentId = existingReview.CommentId,
                    Rating = existingReview.Rating,
                    CommentText = existingReview.CommentText,
                    DatePosted = existingReview.DatePosted,
                    UserId = existingReview.UserId,
                    MovieId = existingReview.MovieId,
                    Timings = existingReview.Timings
                };
            }
            return null; // No changes saved (e.g., no actual change or database error)
        }

        //******Delete
        public async Task<bool> DeleteReviewAsync(int id)
        {
            // FIX: Changed 'this.Reviews.FindAsync(id)' to '_context.Reviews.FindAsync(id)'
            var reviewToDelete = await _context.Reviews.FindAsync(id);

            if (reviewToDelete == null)
            {
                return false; // Review not found
            }

            // FIX: Changed 'this.Reviews.Remove(reviewToDelete)' to '_context.Reviews.Remove(reviewToDelete)'
            _context.Reviews.Remove(reviewToDelete);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0;
        }
    }

   
}