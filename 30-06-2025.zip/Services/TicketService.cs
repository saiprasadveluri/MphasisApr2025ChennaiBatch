﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Book.Services
{
    public class TicketService
    {
        private readonly BookMyShowDbContext _context; // Inject DbContext

        public TicketService(BookMyShowDbContext context)
        {
            _context = context;
        }

        private string GenerateTicketReference()
        {
            return "TIK" + Guid.NewGuid().ToString().Substring(0, 8).ToUpper();
        }

        public async Task<List<TicketDTO>> GetAllTicketsAsync()
        {
            // FIX: Changed 'this.Tickets' to '_context.Tickets'
            return await _context.Tickets
                                 .Select(t => new TicketDTO
                                 {
                                     TicketId = t.TicketId,
                                     BookingId = t.BookingId,
                                     SeatId = t.SeatId
                                 })
                                 .ToListAsync();
        }

        public async Task<TicketDTO?> GetTicketByIdAsync(int id) // Changed return type to TicketDTO?
        {
            // FIX: Changed 'this.Tickets.FindAsync(id)' to '_context.Tickets.FindAsync(id)'
            var ticket = await _context.Tickets.FindAsync(id);

            if (ticket == null)
            {
                return null;
            }

            return new TicketDTO
            {
                TicketId = ticket.TicketId,
                BookingId = ticket.BookingId,
                SeatId = ticket.SeatId
            };
        }

        public async Task<List<TicketDTO>> GetTicketsByBookingIdAsync(int bookingId)
        {
            // FIX: Changed 'this.Tickets' to '_context.Tickets'
            return await _context.Tickets
                                 .Where(t => t.BookingId == bookingId)
                                 .Select(t => new TicketDTO
                                 {
                                     TicketId = t.TicketId,
                                     BookingId = t.BookingId,
                                     SeatId = t.SeatId
                                 })
                                 .ToListAsync();
        }

        public async Task<TicketDTO?> CreateTicketAsync(int bookingId, int seatId) // Changed return type to TicketDTO?
        {
            if (bookingId <= 0 || seatId <= 0)
            {
                throw new ArgumentException("Invalid BookingId or SeatId.");
            }

            // FIX: Changed 'this.Bookings' to '_context.Bookings'
            var bookingExists = await _context.Bookings.AnyAsync(b => b.BookingId == bookingId);
            if (!bookingExists)
            {
                throw new InvalidOperationException($"Booking with ID {bookingId} not found.");
            }

            // FIX: Changed 'this.Seats' to '_context.Seats'
            var seatExists = await _context.Seats.AnyAsync(s => s.SeatId == seatId);
            if (!seatExists)
            {
                throw new InvalidOperationException($"Seat with ID {seatId} not found.");
            }

            // FIX: Changed 'this.Tickets' to '_context.Tickets'
            var isSeatAlreadyTicketedInBooking = await _context.Tickets
                                                                .AnyAsync(t => t.BookingId == bookingId && t.SeatId == seatId);
            if (isSeatAlreadyTicketedInBooking)
            {
                throw new InvalidOperationException($"Seat ID {seatId} is already assigned a ticket within Booking ID {bookingId}.");
            }

            var ticket = new Ticket
            {
                BookingId = bookingId,
                SeatId = seatId,
            };

            // FIX: Changed 'this.Tickets.Add(ticket)' to '_context.Tickets.Add(ticket)'
            _context.Tickets.Add(ticket);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new TicketDTO
                {
                    TicketId = ticket.TicketId,
                    BookingId = ticket.BookingId,
                    SeatId = ticket.SeatId
                };
            }
            return null;
        }

        public async Task<TicketDTO?> UpdateTicketAsync(int id, TicketDTO ticketUpdate) // Changed return type to TicketDTO?
        {
            // FIX: Changed 'this.Tickets.FindAsync(id)' to '_context.Tickets.FindAsync(id)'
            var existingTicket = await _context.Tickets.FindAsync(id);

            if (existingTicket == null)
            {
                return null;
            }

            if (ticketUpdate.BookingId <= 0 || ticketUpdate.SeatId <= 0)
            {
                throw new ArgumentException("Invalid BookingId or SeatId for update.");
            }

            if (existingTicket.BookingId != ticketUpdate.BookingId)
            {
                // FIX: Changed 'this.Bookings' to '_context.Bookings'
                var bookingExists = await _context.Bookings.AnyAsync(b => b.BookingId == ticketUpdate.BookingId);
                if (!bookingExists)
                {
                    throw new InvalidOperationException($"Booking with ID {ticketUpdate.BookingId} not found for update.");
                }
            }

            if (existingTicket.SeatId != ticketUpdate.SeatId)
            {
                // FIX: Changed 'this.Seats' to '_context.Seats'
                var seatExists = await _context.Seats.AnyAsync(s => s.SeatId == ticketUpdate.SeatId);
                if (!seatExists)
                {
                    throw new InvalidOperationException($"Seat with ID {ticketUpdate.SeatId} not found for update.");
                }

                // FIX: Changed 'this.Tickets' to '_context.Tickets'
                var isNewSeatAlreadyTicketedInBooking = await _context.Tickets
                                                                    .AnyAsync(t => t.BookingId == ticketUpdate.BookingId &&
                                                                                    t.SeatId == ticketUpdate.SeatId &&
                                                                                    t.TicketId != id);
                if (isNewSeatAlreadyTicketedInBooking)
                {
                    throw new InvalidOperationException($"Seat ID {ticketUpdate.SeatId} is already assigned a ticket within Booking ID {ticketUpdate.BookingId}.");
                }
            }

            existingTicket.BookingId = ticketUpdate.BookingId;
            existingTicket.SeatId = ticketUpdate.SeatId;

            // FIX: Changed 'this.Entry(existingTicket).State' to '_context.Entry(existingTicket).State'
            _context.Entry(existingTicket).State = EntityState.Modified;
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new TicketDTO
                {
                    TicketId = existingTicket.TicketId,
                    BookingId = existingTicket.BookingId,
                    SeatId = existingTicket.SeatId
                };
            }
            return null;
        }

        public async Task<bool> DeleteTicketAsync(int id)
        {
            // FIX: Changed 'this.Tickets.FindAsync(id)' to '_context.Tickets.FindAsync(id)'
            var ticketToDelete = await _context.Tickets.FindAsync(id);

            if (ticketToDelete == null)
            {
                return false;
            }

            // FIX: Changed 'this.Tickets.Remove(ticketToDelete)' to '_context.Tickets.Remove(ticketToDelete)'
            _context.Tickets.Remove(ticketToDelete);
            // FIX: Changed 'await this.SaveChangesAsync()' to '_context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0;
        }
    }
}