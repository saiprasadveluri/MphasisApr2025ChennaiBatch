﻿using Book.Data; // For the City entity
using Book.Data.DB; // For BookMyShowDbContext
using Book.DTO; // For CityDTO
using Microsoft.EntityFrameworkCore; // For ToListAsync, FindAsync, etc.
namespace Book.Services
{
    public class CityService
    {
        private readonly BookMyShowDbContext _context; // Correctly declared and assigned in constructor

        public CityService(BookMyShowDbContext context)
        {
            _context = context; // Assign the injected context to the private field
        }

        //*****Listing all Cities
        public async Task<List<CityDTO>> GetAllCities()
        {
            // FIX: Changed 'this.Cities' to '_context.Cities'
            return await _context.Cities
                                 .Select(c => new CityDTO
                                 {
                                     CityId = c.CityId,
                                     CityName = c.CityName,
                                     State = c.State,
                                     Country = c.Country
                                 })
                                 .ToListAsync();
        }


        //***** getting City by ID
        public async Task<CityDTO?> GetCityById(int id) // Changed return type to CityDTO? for nullability
        {
            // FIX: Changed 'this.Cities.FindAsync(id)' to '_context.Cities.FindAsync(id)'
            var city = await _context.Cities.FindAsync(id);

            if (city == null)
            {
                return null;
            }

            return new CityDTO
            {
                CityId = city.CityId,
                CityName = city.CityName,
                State = city.State,
                Country = city.Country
            };
        }

        //**** Create new City
        public async Task<CityDTO?> AddCity(CityDTO cityCreate) // Changed parameter to CityCreateDTO for better practice and return to CityDTO?
        {
            // Input validation (optional but good practice)
            if (string.IsNullOrWhiteSpace(cityCreate.CityName))
            {
                throw new ArgumentException("City name cannot be empty.", nameof(cityCreate.CityName));
            }

            // Check for existing city name (optional but good practice)
            if (await _context.Cities.AnyAsync(c => c.CityName == cityCreate.CityName))
            {
                throw new InvalidOperationException($"City with name '{cityCreate.CityName}' already exists.");
            }

            var city = new City
            {
                CityName = cityCreate.CityName,
                State = cityCreate.State,
                Country = cityCreate.Country
            };

            // FIX: Changed 'this.Cities.Add(city)' to '_context.Cities.Add(city)'
            _context.Cities.Add(city);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new CityDTO
                {
                    CityId = city.CityId,
                    CityName = city.CityName,
                    State = city.State,
                    Country = city.Country
                };
            }
            return null;
        }

        //**** Update City
        public async Task<CityDTO?> UpdateCity(int id, CityDTO cityUpdate) // Added Update method and used CityUpdateDTO
        {
            var existingCity = await _context.Cities.FindAsync(id);

            if (existingCity == null)
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(cityUpdate.CityName))
            {
                throw new ArgumentException("City name cannot be empty for update.", nameof(cityUpdate.CityName));
            }

            // Check if updated city name is already taken by another city (excluding current city)
            if (existingCity.CityName != cityUpdate.CityName)
            {
                var nameTaken = await _context.Cities.AnyAsync(c => c.CityName == cityUpdate.CityName && c.CityId != id);
                if (nameTaken)
                {
                    throw new InvalidOperationException($"City name '{cityUpdate.CityName}' is already taken by another city.");
                }
            }

            existingCity.CityName = cityUpdate.CityName;
            existingCity.State = cityUpdate.State;
            existingCity.Country = cityUpdate.Country;

            _context.Entry(existingCity).State = EntityState.Modified;
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new CityDTO
                {
                    CityId = existingCity.CityId,
                    CityName = existingCity.CityName,
                    State = existingCity.State,
                    Country = existingCity.Country
                };
            }
            return null;
        }

        //**** Delete City
        public async Task<bool> DeleteCity(int id) // Changed return type to bool
        {
            // FIX: Changed 'this.Cities.FindAsync(id)' to '_context.Cities.FindAsync(id)'
            var cityToDelete = await _context.Cities.FindAsync(id);

            if (cityToDelete == null)
            {
                return false;
            }

            // FIX: Changed 'this.Cities.Remove(cityToDelete)' to '_context.Cities.Remove(cityToDelete)'
            _context.Cities.Remove(cityToDelete);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0;
        }
    }

    
}