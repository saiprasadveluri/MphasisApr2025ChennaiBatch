﻿using Book.Data; // For the Language entity
using Book.Data.DB; // For BookMyShowDbContext
using Book.DTO; // For LanguageDTO, LanguageCreateDTO, LanguageUpdateDTO (assuming these exist)
using Microsoft.EntityFrameworkCore; // For ToListAsync, FindAsync, etc.
using System.Collections.Generic; // For List<T>
using System.Linq; // For .Select()
using System.Threading.Tasks; // For async/await
using System; // For ArgumentException, InvalidOperationException

namespace Book.Services
{
    public class LanguageService
    {
        private readonly BookMyShowDbContext _context;

        public LanguageService(BookMyShowDbContext context)
        {
            _context = context; // Assign the injected context to the private field
        }

        //** List of all Languages
        public async Task<List<LanguageDTO>> GetAllLanguages()
        {
            // FIX: Changed 'this.Languages' to '_context.Languages'
            return await _context.Languages
                                 .Select(l => new LanguageDTO
                                 {
                                     LanguageId = l.LanguageId,
                                     LanguageName = l.LanguageName
                                 })
                                 .ToListAsync();
        }

        //**********by Id
        public async Task<LanguageDTO?> GetLanguageById(int id) // Changed return type to LanguageDTO?
        {
            // FIX: Changed 'this.Languages.FindAsync(id)' to '_context.Languages.FindAsync(id)'
            var language = await _context.Languages.FindAsync(id);

            if (language == null)
            {
                return null;
            }

            return new LanguageDTO
            {
                LanguageId = language.LanguageId,
                LanguageName = language.LanguageName
            };
        }

        //********* Create Operation
        public async Task<LanguageDTO?> CreateLanguage(LanguageDTO languageCreate) // Changed parameter to LanguageCreateDTO and return to LanguageDTO?
        {
            if (string.IsNullOrWhiteSpace(languageCreate.LanguageName))
            {
                throw new ArgumentException("Language name cannot be empty or whitespace.", nameof(languageCreate.LanguageName));
            }

            // Optional: Check if a language with the same name already exists
            if (await _context.Languages.AnyAsync(l => l.LanguageName == languageCreate.LanguageName))
            {
                throw new InvalidOperationException($"Language with name '{languageCreate.LanguageName}' already exists.");
            }

            var language = new Language
            {
                LanguageName = languageCreate.LanguageName
            };

            // FIX: Changed 'this.Languages.Add(language)' to '_context.Languages.Add(language)'
            _context.Languages.Add(language);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new LanguageDTO
                {
                    LanguageId = language.LanguageId,
                    LanguageName = language.LanguageName
                };
            }
            return null;
        }

        // **** Update Language (Added for completeness)
        public async Task<LanguageDTO?> UpdateLanguage(int id, LanguageDTO languageUpdate)
        {
            var existingLanguage = await _context.Languages.FindAsync(id);

            if (existingLanguage == null)
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(languageUpdate.LanguageName))
            {
                throw new ArgumentException("Language name cannot be empty or whitespace for update.", nameof(languageUpdate.LanguageName));
            }

            // Check if updated language name is already taken by another language (excluding current language)
            if (existingLanguage.LanguageName != languageUpdate.LanguageName)
            {
                var nameTaken = await _context.Languages.AnyAsync(l => l.LanguageName == languageUpdate.LanguageName && l.LanguageId != id);
                if (nameTaken)
                {
                    throw new InvalidOperationException($"Language name '{languageUpdate.LanguageName}' is already taken by another language.");
                }
            }

            existingLanguage.LanguageName = languageUpdate.LanguageName;

            _context.Entry(existingLanguage).State = EntityState.Modified;
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new LanguageDTO
                {
                    LanguageId = existingLanguage.LanguageId,
                    LanguageName = existingLanguage.LanguageName
                };
            }
            return null;
        }

        //****Delete
        public async Task<bool> DeleteLanguage(int id)
        {
            // FIX: Changed 'this.Languages.FindAsync(id)' to '_context.Languages.FindAsync(id)'
            var languageToDelete = await _context.Languages.FindAsync(id);

            if (languageToDelete == null)
            {
                return false; // Return false if the language was not found.
            }

            // FIX: Changed 'this.Languages.Remove(languageToDelete)' to '_context.Languages.Remove(languageToDelete)'
            _context.Languages.Remove(languageToDelete);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0; // Return true if at least one record was affected (deleted).
        }
    }

    // Remember to create these DTOs in your Book.DTO namespace (e.g., Book.DTO/LanguageDTO.cs)
    /*
    namespace Book.DTO
    {
        public class LanguageDTO
        {
            public int LanguageId { get; set; }
            public string LanguageName { get; set; }
        }

        public class LanguageCreateDTO
        {
            public string LanguageName { get; set; }
        }

        public class LanguageUpdateDTO
        {
            public string LanguageName { get; set; }
        }
    }
    */
}