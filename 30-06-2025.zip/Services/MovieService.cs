﻿using Book.Data; // For the Movie entity
using Book.Data.DB; // For BookMyShowDbContext
using Book.DTO; // For MovieDTO, MovieCreateDTO, MovieUpdateDTO (assuming these exist)
using Microsoft.EntityFrameworkCore; // For ToListAsync, FindAsync, etc.


namespace Book.Services
{
    public class MovieService
    {
        private readonly BookMyShowDbContext _context;

        public MovieService(BookMyShowDbContext context)
        {
            _context = context; // Assign the injected context to the private field
        }

        public async Task<List<MovieDTO>> GetAllMovies()
        {
            // FIX: Changed 'this.Movies' to '_context.Movies'
            return await _context.Movies
                                 .Select(m => new MovieDTO
                                 {
                                     MovieId = m.MovieId,
                                     Title = m.Title,
                                     Description = m.Description,
                                     GenreId = m.GenreId,
                                     ReleaseDate = m.ReleaseDate
                                 })
                                 .ToListAsync();
        }

        //***By Id
        public async Task<MovieDTO?> GetMovieById(int id) // Changed return type to MovieDTO?
        {
            // FIX: Changed 'this.Movies.FindAsync(id)' to '_context.Movies.FindAsync(id)'
            var movie = await _context.Movies.FindAsync(id);

            if (movie == null)
            {
                return null;
            }

            return new MovieDTO
            {
                MovieId = movie.MovieId,
                Title = movie.Title,
                Description = movie.Description,
                GenreId = movie.GenreId,
                ReleaseDate = movie.ReleaseDate
            };
        }

        //******Create Operation
        public async Task<MovieDTO?> Add(MovieDTO movieCreate) // Changed parameter to MovieCreateDTO and return to MovieDTO?
        {
            if (string.IsNullOrWhiteSpace(movieCreate.Title))
            {
                throw new ArgumentException("Movie title cannot be empty or whitespace.", nameof(movieCreate.Title));
            }
            if (movieCreate.GenreId <= 0) // Assuming GenreId must be a positive integer
            {
                throw new ArgumentException("Invalid GenreId.", nameof(movieCreate.GenreId));
            }

            // Optional: Check if the genre actually exists
            var genreExists = await _context.Genres.AnyAsync(g => g.GenreId == movieCreate.GenreId);
            if (!genreExists)
            {
                throw new ArgumentException($"Genre with ID {movieCreate.GenreId} does not exist.", nameof(movieCreate.GenreId));
            }

            var movie = new Movie
            {
                Title = movieCreate.Title,
                Description = movieCreate.Description,
                GenreId = movieCreate.GenreId,
                ReleaseDate = movieCreate.ReleaseDate
            };

            // FIX: Changed 'this.Movies.Add(movie)' to '_context.Movies.Add(movie)'
            _context.Movies.Add(movie);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new MovieDTO
                {
                    MovieId = movie.MovieId,
                    Title = movie.Title,
                    Description = movie.Description,
                    GenreId = movie.GenreId,
                    ReleaseDate = movie.ReleaseDate
                };
            }
            return null;
        }

        //******Update Operation (Added for completeness)
        public async Task<MovieDTO?> UpdateMovie(int id, MovieDTO movieUpdate)
        {
            var existingMovie = await _context.Movies.FindAsync(id);

            if (existingMovie == null)
            {
                return null; // Movie not found
            }

            if (string.IsNullOrWhiteSpace(movieUpdate.Title))
            {
                throw new ArgumentException("Movie title cannot be empty or whitespace for update.", nameof(movieUpdate.Title));
            }

            if (movieUpdate.GenreId <= 0)
            {
                throw new ArgumentException("Invalid GenreId for update.", nameof(movieUpdate.GenreId));
            }

            // Optional: Check if the new genre actually exists
            if (existingMovie.GenreId != movieUpdate.GenreId) // Only check if genre is changing
            {
                var genreExists = await _context.Genres.AnyAsync(g => g.GenreId == movieUpdate.GenreId);
                if (!genreExists)
                {
                    throw new ArgumentException($"Genre with ID {movieUpdate.GenreId} does not exist for update.", nameof(movieUpdate.GenreId));
                }
            }


            existingMovie.Title = movieUpdate.Title;
            existingMovie.Description = movieUpdate.Description;
            existingMovie.GenreId = movieUpdate.GenreId;
            existingMovie.ReleaseDate = movieUpdate.ReleaseDate;

            _context.Entry(existingMovie).State = EntityState.Modified; // Explicitly mark as modified
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new MovieDTO
                {
                    MovieId = existingMovie.MovieId,
                    Title = existingMovie.Title,
                    Description = existingMovie.Description,
                    GenreId = existingMovie.GenreId,
                    ReleaseDate = existingMovie.ReleaseDate
                };
            }
            return null;
        }

        //****Delete Operation
        public async Task<bool> DeleteMovie(int id)
        {
            // FIX: Changed 'this.Movies.FindAsync(id)' to '_context.Movies.FindAsync(id)'
            var movieToDelete = await _context.Movies.FindAsync(id);

            if (movieToDelete == null)
            {
                return false; // Movie not found
            }

            // FIX: Changed 'this.Movies.Remove(movieToDelete)' to '_context.Movies.Remove(movieToDelete)'
            _context.Movies.Remove(movieToDelete);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0;
        }
    }

    // Remember to create these DTOs in your Book.DTO namespace (e.g., Book.DTO/MovieDTO.cs)
    /*
    namespace Book.DTO
    {
        public class MovieDTO
        {
            public int MovieId { get; set; }
            public string Title { get; set; }
            public string Description { get; set; }
            public int GenreId { get; set; }
            public DateTime ReleaseDate { get; set; }
            // Add other relevant properties like Language, Rating, Duration, etc.
        }

        public class MovieCreateDTO
        {
            public string Title { get; set; }
            public string Description { get; set; }
            public int GenreId { get; set; }
            public DateTime ReleaseDate { get; set; }
        }

        public class MovieUpdateDTO
        {
            public string Title { get; set; }
            public string Description { get; set; }
            public int GenreId { get; set; }
            public DateTime ReleaseDate { get; set; }
        }
    }
    */
}