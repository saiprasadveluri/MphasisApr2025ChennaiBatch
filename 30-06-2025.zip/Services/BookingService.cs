﻿using Book.Data.DB;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class BookingService 
    {
        private readonly BookMyShowDbContext _context;

        // 3. The constructor now accepts BookMyShowDbContext directly
        public BookingService(BookMyShowDbContext context) // No longer takes DbContextOptions
        {
            _context = context; // Assign the injected context to the private field
        }


        public async Task<Booking> Add(Booking booking)
        {
            _context.Bookings.Add(booking); // Uses _context to access the Bookings DbSet and add a new booking
            await _context.SaveChangesAsync(); // Uses _context to save changes to the database
            return booking;
        }

        public async Task<IEnumerable<Booking>> GetBookingsByUserId(int userId)
        {

            return await _context.Bookings
                .Where(b => b.UserId == userId)
                .ToListAsync();
        }

        public async Task<IEnumerable<Booking>> GetAllBooking() // Duplicate of GetByUserIdAsync
        {
            return await _context.Bookings.ToListAsync();
        }

        public async Task UpdateBooking(int bookingId, string status)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking != null)
            {
                booking.Status = status;
                await _context.SaveChangesAsync();
            }
        }

        public async Task Reschedule(int bookingId, DateTime newDate)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking != null)
            {
                booking.BookingDate = newDate;

                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> CancelBooking(int bookingId)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking == null)
            {
                return false; // Booking not found
            }

            booking.Status = "Cancelled"; // Or your desired cancelled status
            int savedChanges = await _context.SaveChangesAsync();
            return savedChanges > 0;


        }



 

    


    }
}
