﻿using Book.Data; // For the Show entity
using Book.Data.DB; // For BookMyShowDbContext
using Book.DTO; // For ShowDTO, ShowCreateDTO, ShowUpdateDTO (assuming these exist)
using Microsoft.EntityFrameworkCore; // For ToListAsync, FindAsync, etc.
using System.Collections.Generic; // For List<T>
using System.Linq; // For .Select(), .Where(), .OrderBy(), .ThenBy()
using System.Threading.Tasks; // For async/await
using System; // For DateTime, ArgumentException, InvalidOperationException

namespace Book.Services
{
    public class ShowService
    {
        private readonly BookMyShowDbContext _context;

        public ShowService(BookMyShowDbContext context)
        {
            _context = context; // Assign the injected context to the private field
        }

        public async Task<List<ShowDTO>> GetAllShowsAsync()
        {
            // FIX: Changed 'this.Shows' to '_context.Shows'
            return await _context.Shows
                                 .Select(s => new ShowDTO
                                 {
                                     ShowId = s.ShowId,
                                     ShowDate = s.ShowDate,
                                     ShowTime = s.ShowTime,
                                     AvailableSeates = s.AvailableSeates,
                                     Price = s.Price,
                                     TheatreId = s.TheatreId
                                 })
                                 .ToListAsync();
        }

        //** By Id
        public async Task<ShowDTO?> GetShowByIdAsync(int id) // Changed return type to ShowDTO?
        {
            // FIX: Changed 'this.Shows.FindAsync(id)' to '_context.Shows.FindAsync(id)'
            var show = await _context.Shows.FindAsync(id);

            if (show == null)
            {
                return null;
            }

            return new ShowDTO
            {
                ShowId = show.ShowId,
                ShowDate = show.ShowDate,
                ShowTime = show.ShowTime,
                AvailableSeates = show.AvailableSeates,
                Price = show.Price,
                TheatreId = show.TheatreId
            };
        }

        //Theaters by Date
        public async Task<List<ShowDTO>> GetShowsByTheatreAndDateAsync(int theatreId, DateTime? date = null)
        {
            // FIX: Changed 'this.Shows' to '_context.Shows'
            var query = _context.Shows.Where(s => s.TheatreId == theatreId);

            if (date.HasValue)
            {
                query = query.Where(s => s.ShowDate.Date == date.Value.Date);
            }

            return await query
                                 .OrderBy(s => s.ShowDate)
                                 .ThenBy(s => s.ShowTime)
                                 .Select(s => new ShowDTO
                                 {
                                     ShowId = s.ShowId,
                                     ShowDate = s.ShowDate,
                                     ShowTime = s.ShowTime,
                                     AvailableSeates = s.AvailableSeates,
                                     Price = s.Price,
                                     TheatreId = s.TheatreId
                                 })
                                 .ToListAsync();
        }

        //*** Create Operation (Added for completeness)
        public async Task<ShowDTO?> CreateShowAsync(ShowDTO showCreate) // Changed parameter to ShowCreateDTO and return to ShowDTO?
        {
            // Basic validation
            if (showCreate.ShowDate == default(DateTime))
            {
                throw new ArgumentException("ShowDate cannot be default.", nameof(showCreate.ShowDate));
            }
            if (showCreate.AvailableSeates < 0)
            {
                throw new ArgumentException("AvailableSeats cannot be negative.", nameof(showCreate.AvailableSeates));
            }
            if (showCreate.Price < 0)
            {
                throw new ArgumentException("Price cannot be negative.", nameof(showCreate.Price));
            }
            if (showCreate.TheatreId <= 0)
            {
                throw new ArgumentException("Invalid TheatreId.", nameof(showCreate.TheatreId));
            }

            // Check if TheatreId exists
            // FIX: Changed 'this.Theatres' to '_context.Theatres'
            var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == showCreate.TheatreId);
            if (!theatreExists)
            {
                throw new ArgumentException($"Theatre with ID {showCreate.TheatreId} does not exist.", nameof(showCreate.TheatreId));
            }

            // Prevent duplicate shows for the same theatre, date, and time
            // FIX: Changed 'this.Shows' to '_context.Shows'
            var duplicateShow = await _context.Shows
                                              .AnyAsync(s => s.TheatreId == showCreate.TheatreId &&
                                                             s.ShowDate.Date == showCreate.ShowDate.Date &&
                                                             s.ShowTime == showCreate.ShowTime);
            if (duplicateShow)
            {
                throw new InvalidOperationException($"A show already exists for Theatre {showCreate.TheatreId} at {showCreate.ShowDate.ToShortDateString()} {showCreate.ShowTime}.");
            }

            var show = new Show
            {
                ShowDate = showCreate.ShowDate.Date, // Store only the date part if time is separate
                ShowTime = showCreate.ShowTime,
                AvailableSeates = showCreate.AvailableSeates,
                Price = showCreate.Price,
                TheatreId = showCreate.TheatreId
            };

            // FIX: Changed 'this.Shows.Add(show)' to '_context.Shows.Add(show)'
            _context.Shows.Add(show);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new ShowDTO
                {
                    ShowId = show.ShowId, // ID will be populated after SaveChangesAsync
                    ShowDate = show.ShowDate,
                    ShowTime = show.ShowTime,
                    AvailableSeates = show.AvailableSeates,
                    Price = show.Price,
                    TheatreId = show.TheatreId
                };
            }
            return null;
        }

        public async Task<ShowDTO?> UpdateShowAsync(int id, ShowDTO showUpdate) // Changed parameter to ShowUpdateDTO and return to ShowDTO?
        {
            // FIX: Changed 'this.Shows.FindAsync(id)' to '_context.Shows.FindAsync(id)'
            var existingShow = await _context.Shows.FindAsync(id);

            if (existingShow == null)
            {
                return null;
            }

            // Basic validation for update
            if (showUpdate.ShowDate == default(DateTime))
            {
                throw new ArgumentException("ShowDate cannot be default for update.", nameof(showUpdate.ShowDate));
            }
            if (showUpdate.AvailableSeates < 0)
            {
                throw new ArgumentException("AvailableSeats cannot be negative for update.", nameof(showUpdate.AvailableSeates));
            }
            if (showUpdate.Price < 0)
            {
                throw new ArgumentException("Price cannot be negative for update.", nameof(showUpdate.Price));
            }
            if (showUpdate.TheatreId <= 0)
            {
                throw new ArgumentException("Invalid TheatreId for update.", nameof(showUpdate.TheatreId));
            }

            // Check if TheatreId exists if it's being changed
            if (existingShow.TheatreId != showUpdate.TheatreId)
            {
                // FIX: Changed 'this.Theatres' to '_context.Theatres'
                var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == showUpdate.TheatreId);
                if (!theatreExists) { throw new InvalidOperationException("Specified new TheatreId does not exist."); }
            }

            // Prevent duplicate shows for the same theatre, date, and time (excluding the current show)
            // FIX: Changed 'this.Shows' to '_context.Shows'
            var duplicateShow = await _context.Shows
                                              .AnyAsync(s => s.TheatreId == showUpdate.TheatreId &&
                                                             s.ShowDate.Date == showUpdate.ShowDate.Date &&
                                                             s.ShowTime == showUpdate.ShowTime &&
                                                             s.ShowId != id);
            if (duplicateShow)
            {
                throw new InvalidOperationException($"A show already exists for Theatre {showUpdate.TheatreId} at {showUpdate.ShowDate.ToShortDateString()} {showUpdate.ShowTime}.");
            }

            existingShow.ShowDate = showUpdate.ShowDate.Date; // Store only the date part
            existingShow.ShowTime = showUpdate.ShowTime;
            existingShow.AvailableSeates = showUpdate.AvailableSeates;
            existingShow.Price = showUpdate.Price;
            existingShow.TheatreId = showUpdate.TheatreId;

            // FIX: Changed 'this.Entry(existingShow).State' to '_context.Entry(existingShow).State'
            _context.Entry(existingShow).State = EntityState.Modified;
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new ShowDTO
                {
                    ShowId = existingShow.ShowId,
                    ShowDate = existingShow.ShowDate,
                    ShowTime = existingShow.ShowTime,
                    AvailableSeates = existingShow.AvailableSeates,
                    Price = existingShow.Price,
                    TheatreId = existingShow.TheatreId
                };
            }
            return null;
        }

        //Delete Show
        public async Task<bool> DeleteShowAsync(int id)
        {
            // FIX: Changed 'this.Shows.FindAsync(id)' to '_context.Shows.FindAsync(id)'
            var showToDelete = await _context.Shows.FindAsync(id);

            if (showToDelete == null)
            {
                return false;
            }

            // FIX: Changed 'this.Shows.Remove(showToDelete)' to '_context.Shows.Remove(showToDelete)'
            _context.Shows.Remove(showToDelete);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0;
        }
    }

    // Remember to create these DTOs in your Book.DTO namespace (e.g., Book.DTO/ShowDTO.cs)
    /*
    namespace Book.DTO
    {
        public class ShowDTO
        {
            public int ShowId { get; set; }
            public DateTime ShowDate { get; set; }
            public TimeSpan ShowTime { get; set; } // Assuming ShowTime is a TimeSpan
            public int AvailableSeates { get; set; }
            public decimal Price { get; set; }
            public int TheatreId { get; set; }
            // Add MovieId if a show is always tied to a specific movie
            // public int MovieId { get; set; }
        }

        public class ShowCreateDTO
        {
            public DateTime ShowDate { get; set; }
            public TimeSpan ShowTime { get; set; }
            public int AvailableSeates { get; set; }
            public decimal Price { get; set; }
            public int TheatreId { get; set; }
            // public int MovieId { get; set; } // If a show is always tied to a specific movie
        }

        public class ShowUpdateDTO
        {
            public DateTime ShowDate { get; set; }
            public TimeSpan ShowTime { get; set; }
            public int AvailableSeates { get; set; }
            public decimal Price { get; set; }
            public int TheatreId { get; set; } // Allow changing theatre if needed, or remove
            // public int MovieId { get; set; } // If movie can be changed after creation
        }
    }
    */
}