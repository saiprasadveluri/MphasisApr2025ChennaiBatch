﻿using Book.Data; // For the Seat entity
using Book.Data.DB; // For BookMyShowDbContext
using Book.DTO; // For SeatDTO, SeatCreateDTO, SeatUpdateDTO (assuming these exist)
using Microsoft.EntityFrameworkCore; // For ToListAsync, FindAsync, etc.

namespace Book.Services
{
    public class SeatService
    {
        private readonly BookMyShowDbContext _context;

        public SeatService(BookMyShowDbContext context)
        {
            _context = context;
        }

        //*** all Seats
        public async Task<List<SeatDTO>> GetAllSeatsAsync()
        {
            // FIX: Changed 'this.Seats' to '_context.Seats'
            return await _context.Seats
                                 .Select(s => new SeatDTO
                                 {
                                     SeatId = s.SeatId,
                                     SeatNumber = s.SeatNumber,
                                     Row = s.Row,
                                     Type = s.Type,
                                     Status = s.Status,
                                     TheatreId = s.TheatreId
                                 })
                                 .ToListAsync();
        }

        public async Task<SeatDTO?> GetSeatByIdAsync(int id) // Changed return type to SeatDTO?
        {
            // FIX: Changed 'this.Seats.FindAsync(id)' to '_context.Seats.FindAsync(id)'
            var seat = await _context.Seats.FindAsync(id);

            if (seat == null)
            {
                return null;
            }

            return new SeatDTO
            {
                SeatId = seat.SeatId,
                SeatNumber = seat.SeatNumber,
                Row = seat.Row,
                Type = seat.Type,
                Status = seat.Status,
                TheatreId = seat.TheatreId
            };
        }

        public async Task<List<SeatDTO>> GetSeatsByTheatreIdAsync(int theatreId)
        {
            // FIX: Changed 'this.Seats' to '_context.Seats'
            return await _context.Seats
                                 .Where(s => s.TheatreId == theatreId)
                                 .Select(s => new SeatDTO
                                 {
                                     SeatId = s.SeatId,
                                     SeatNumber = s.SeatNumber,
                                     Row = s.Row,
                                     Type = s.Type,
                                     Status = s.Status,
                                     TheatreId = s.TheatreId
                                 })
                                 .ToListAsync();
        }

        //*** Create Operation (Added for completeness)
        public async Task<SeatDTO?> CreateSeatAsync(SeatDTO seatCreate) // Changed parameter to SeatCreateDTO and return to SeatDTO?
        {
            // Basic validation
            if (string.IsNullOrWhiteSpace(seatCreate.SeatNumber.ToString()))
            {
                throw new ArgumentException("Seat number cannot be empty or whitespace.", nameof(seatCreate.SeatNumber));
            }
            if (string.IsNullOrWhiteSpace(seatCreate.Row.ToString()))
            {
                throw new ArgumentException("Row cannot be empty or whitespace.", nameof(seatCreate.Row));
            }
            if (seatCreate.TheatreId <= 0)
            {
                throw new ArgumentException("Invalid TheatreId.", nameof(seatCreate.TheatreId));
            }

            // Optional: Check if TheatreId exists
            var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == seatCreate.TheatreId);
            if (!theatreExists)
            {
                throw new ArgumentException($"Theatre with ID {seatCreate.TheatreId} does not exist.", nameof(seatCreate.TheatreId));
            }

            // Optional: Prevent duplicate seat number/row within the same theatre
            var existingSeat = await _context.Seats
                                             .AnyAsync(s => s.TheatreId == seatCreate.TheatreId &&
                                                            s.SeatNumber == seatCreate.SeatNumber &&
                                                            s.Row == seatCreate.Row);
            if (existingSeat)
            {
                throw new InvalidOperationException($"Seat {seatCreate.SeatNumber} in row {seatCreate.Row} already exists for Theatre ID {seatCreate.TheatreId}.");
            }


            var seat = new Seat
            {
                SeatNumber = seatCreate.SeatNumber,
                Row = seatCreate.Row,
                Type = seatCreate.Type,     // Assuming type is a string/enum, validate if needed
                Status = seatCreate.Status, // Assuming status is a string/enum, validate if needed
                TheatreId = seatCreate.TheatreId
            };

            _context.Seats.Add(seat);
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new SeatDTO
                {
                    SeatId = seat.SeatId,
                    SeatNumber = seat.SeatNumber,
                    Row = seat.Row,
                    Type = seat.Type,
                    Status = seat.Status,
                    TheatreId = seat.TheatreId
                };
            }
            return null;
        }

        //*** Update Operation (Added for completeness)
        public async Task<SeatDTO?> UpdateSeatAsync(int id, SeatDTO seatUpdate)
        {
            var existingSeat = await _context.Seats.FindAsync(id);

            if (existingSeat == null)
            {
                return null; // Seat not found
            }

            // Basic validation for update
            if (string.IsNullOrWhiteSpace(seatUpdate.SeatNumber.ToString()))
            {
                throw new ArgumentException("Seat number cannot be empty or whitespace for update.", nameof(seatUpdate.SeatNumber));
            }
            if (string.IsNullOrWhiteSpace(seatUpdate.Row.ToString()))
            {
                throw new ArgumentException("Row cannot be empty or whitespace for update.", nameof(seatUpdate.Row));
            }
            if (seatUpdate.TheatreId <= 0)
            {
                throw new ArgumentException("Invalid TheatreId for update.", nameof(seatUpdate.TheatreId));
            }

            // Optional: Check if TheatreId exists (if it's being updated)
            if (existingSeat.TheatreId != seatUpdate.TheatreId)
            {
                var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == seatUpdate.TheatreId);
                if (!theatreExists)
                {
                    throw new ArgumentException($"Theatre with ID {seatUpdate.TheatreId} does not exist.", nameof(seatUpdate.TheatreId));
                }
            }

            // Optional: Prevent changing to a duplicate seat number/row within the target theatre
            if (existingSeat.SeatNumber != seatUpdate.SeatNumber ||
                existingSeat.Row != seatUpdate.Row ||
                existingSeat.TheatreId != seatUpdate.TheatreId)
            {
                var duplicateSeat = await _context.Seats
                                                  .AnyAsync(s => s.TheatreId == seatUpdate.TheatreId &&
                                                                 s.SeatNumber == seatUpdate.SeatNumber &&
                                                                 s.Row == seatUpdate.Row &&
                                                                 s.SeatId != id); // Exclude the current seat
                if (duplicateSeat)
                {
                    throw new InvalidOperationException($"Seat {seatUpdate.SeatNumber} in row {seatUpdate.Row} already exists for Theatre ID {seatUpdate.TheatreId}.");
                }
            }


            existingSeat.SeatNumber = seatUpdate.SeatNumber;
            existingSeat.Row = seatUpdate.Row;
            existingSeat.Type = seatUpdate.Type;
            existingSeat.Status = seatUpdate.Status;
            existingSeat.TheatreId = seatUpdate.TheatreId;

            _context.Entry(existingSeat).State = EntityState.Modified; // Explicitly mark as modified
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new SeatDTO
                {
                    SeatId = existingSeat.SeatId,
                    SeatNumber = existingSeat.SeatNumber,
                    Row = existingSeat.Row,
                    Type = existingSeat.Type,
                    Status = existingSeat.Status,
                    TheatreId = existingSeat.TheatreId
                };
            }
            return null;
        }

        public async Task<bool> DeleteSeatAsync(int id)
        {
            // FIX: Changed 'this.Seats.FindAsync(id)' to '_context.Seats.FindAsync(id)'
            var seatToDelete = await _context.Seats.FindAsync(id);

            if (seatToDelete == null)
            {
                return false; // Seat not found
            }

            // FIX: Changed 'this.Seats.Remove(seatToDelete)' to '_context.Seats.Remove(seatToDelete)'
            _context.Seats.Remove(seatToDelete);
            // FIX: Changed 'await this.SaveChangesAsync()' to 'await _context.SaveChangesAsync()'
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0;
        }
    }

    // Remember to create these DTOs in your Book.DTO namespace (e.g., Book.DTO/SeatDTO.cs)
    /*
    namespace Book.DTO
    {
        public class SeatDTO
        {
            public int SeatId { get; set; }
            public string SeatNumber { get; set; } // e.g., "A1", "B12"
            public string Row { get; set; }       // e.g., "A", "B", "C"
            public string Type { get; set; }      // e.g., "Standard", "Premium", "VIP"
            public string Status { get; set; }    // e.g., "Available", "Booked", "Reserved"
            public int TheatreId { get; set; }
        }

        public class SeatCreateDTO
        {
            public string SeatNumber { get; set; }
            public string Row { get; set; }
            public string Type { get; set; }
            public string Status { get; set; }
            public int TheatreId { get; set; }
        }

        public class SeatUpdateDTO
        {
            public string SeatNumber { get; set; }
            public string Row { get; set; }
            public string Type { get; set; }
            public string Status { get; set; }
            public int TheatreId { get; set; } // Allow changing theatre if needed, or remove
        }
    }
    */
}