﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GenreController : ControllerBase
    {
        private readonly GenreService _genreService;

        public GenreController(GenreService genreService)
        {
            _genreService = genreService;
        }

        [HttpGet]
        public async Task<ActionResult<List<GenreDTO>>> GetAllGenres()
        {
            var genres = await _genreService.GetAllGenres();
            return Ok(genres);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<GenreDTO>> GetGenreById(int id)
        {
            var genre = await _genreService.GetGenreById(id);
            if (genre == null)
                return NotFound($"Genre with ID {id} not found.");

            return Ok(genre);
        }

        [HttpPost]
        public async Task<ActionResult<GenreDTO>> Add(GenreDTO genreDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdGenre = await _genreService.Add(genreDto);
            return CreatedAtAction(nameof(GetGenreById), new { id = createdGenre.GenreId }, createdGenre);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<GenreDTO>> UpdateGenre(int id, [FromBody] GenreDTO genreDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (genreDto.GenreId != 0 && genreDto.GenreId != id)
                return BadRequest("Genre ID in the URL does not match the request body.");

            genreDto.GenreId = id;
            var updatedGenre = await _genreService.UpdateGenre(id, genreDto);

            if (updatedGenre == null)
                return NotFound($"Genre with ID {id} not found.");

            return Ok(updatedGenre);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteGenre(int id)
        {
            var success = await _genreService.DeleteGenre(id);
            if (!success)
                return NotFound($"Genre with ID {id} not found.");

            return NoContent();
        }
    }
}
