﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReviewController : ControllerBase
    {
        private readonly ReviewService _reviewService;

        public ReviewController(ReviewService reviewService)
        {
            _reviewService = reviewService;
        }

        [HttpGet]
        public async Task<ActionResult<List<ReviewDTO>>> GetAllReviews()
        {
            var reviews = await _reviewService.GetAllReviews();
            return Ok(reviews);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ReviewDTO>> GetReviewById(int id)
        {
            var review = await _reviewService.GetReviewById(id);
            if (review == null)
                return NotFound($"Review with ID {id} not found.");

            return Ok(review);
        }

        [HttpGet("ByMovie/{movieId}")]
        public async Task<ActionResult<List<ReviewDTO>>> GetReviewsByMovieId(int movieId)
        {
            var reviews = await _reviewService.GetReviewsByMovieId(movieId);
            return Ok(reviews);
        }

        [HttpPost]
        public async Task<ActionResult<ReviewDTO>> CreateReview(ReviewDTO reviewDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdReview = await _reviewService.CreateReview(reviewDto);
            return CreatedAtAction(nameof(GetReviewById), new { id = createdReview.CommentId }, createdReview);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<ReviewDTO>> UpdateReview(int id,  ReviewDTO reviewDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (reviewDto.CommentId != 0 && reviewDto.CommentId != id)
                return BadRequest("Comment ID in the URL does not match the request body.");

            reviewDto.CommentId = id;
            var updatedReview = await _reviewService.UpdateReview(id, reviewDto);
            if (updatedReview == null)
                return NotFound($"Review with ID {id} not found.");

            return Ok(updatedReview);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteReview(int id)
        {
            var success = await _reviewService.DeleteReview(id);
            if (!success)
                return NotFound($"Review with ID {id} not found.");

            return NoContent();
        }
    }
}
