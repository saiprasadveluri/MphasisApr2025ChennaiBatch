﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;

        public UserController(UserService userService)
        {
            _userService = userService;
        }

        //List of All User

        [HttpGet]
        public async Task<ActionResult<List<UserDTO>>> GetAllUsers()
        {
            var users = await _userService.GetAllUsers();
            return Ok(users);
        }
        //By user Id

        [HttpGet("{id}")]
        public async Task<ActionResult<UserDTO>> GetUserById(int id)
        {
            var user = await _userService.GetUserById(id);
            if (user == null)
                return NotFound($"User with ID {id} not found.");

            return Ok(user);
        }

        //By Email
        [HttpGet("ByEmail")]
        public async Task<ActionResult<UserDTO>> GetUserByEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return BadRequest("Email cannot be empty.");

            var user = await _userService.GetUserByEmail(email);
            if (user == null)
                return NotFound($"User with email '{email}' not found.");

            return Ok(user);
        }

        //register
        [HttpPost("Register")]
        public async Task<ActionResult<UserDTO>> RegisterUser([FromBody] UserDTO userRegisterDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdUser = await _userService.CreateUser(userRegisterDto);
            return CreatedAtAction(nameof(GetUserById), new { id = createdUser.UserId }, createdUser);
        }

        [HttpPost("Login")]
        public async Task<ActionResult<UserDTO>> Login([FromBody] LoginDTO loginDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (string.IsNullOrWhiteSpace(loginDto.UserEmail) || string.IsNullOrWhiteSpace(loginDto.Password))
                return BadRequest("Email and Password are required.");

            var user = await _userService.VerifyUserCredentialsAsync(loginDto.UserEmail, loginDto.Password);
            if (user == null)
                return Unauthorized("Invalid email or password.");

            return Ok(user);
        }

        //Update 
        [HttpPut("{id}")]
        public async Task<ActionResult<UserDTO>> UpdateUser(int id,  UserDTO userUpdateDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (userUpdateDto.UserId != 0 && userUpdateDto.UserId != id)
                return BadRequest("User ID mismatch.");

            userUpdateDto.UserId = id;
            var updatedUser = await _userService.UpdateUser(id, userUpdateDto);

            if (updatedUser == null)
                return NotFound($"User with ID {id} not found.");

            return Ok(updatedUser);
        }
        //Change Password
        [HttpPut("ChangePassword/{id}")]
        public async Task<ActionResult> ChangePassword(int id, ChangePasswordDTO changePasswordDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var success = await _userService.ChangePassword(id, changePasswordDto);
            if (!success)
                return NotFound($"User with ID {id} not found.");

            return NoContent();
        }
        //Delete User
        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteUser(int id)
        {
            var success = await _userService.DeleteUser(id);
            if (!success)
                return NotFound($"User with ID {id} not found.");

            return NoContent();
        }
    }
}
