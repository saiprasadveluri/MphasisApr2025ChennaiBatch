﻿using Book.DTO;
using Book.Services;
using Microsoft.AspNetCore.Mvc;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingController : ControllerBase
    {
        private readonly BookingService _bookingService;

        public BookingController(BookingService bookingService)
        {
            _bookingService = bookingService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookingDTO>>> GetAllBookings()
        {
            var bookings = await _bookingService.GetAllBooking();
            var results = bookings.Select(b => new BookingDTO
            {
                BookingId = b.BookingId,
                BookingDate = b.BookingDate,
                NumberOfTickets = b.NumberOfTickets,
                TotalAmount = b.TotalAmount,
                Status = b.Status,
                UserId = b.UserId,
                ShowId = b.MovieShowId,
                NewDate = b.NewDate
            }).ToList();

            return Ok(results);
        }

        [HttpGet("user/{userId}")]
        public async Task<ActionResult<IEnumerable<BookingDTO>>> GetBookingsByUserId(int userId)
        {
            var bookings = await _bookingService.GetBookingsByUserId(userId);
            var results = bookings.Select(b => new BookingDTO
            {
                BookingId = b.BookingId,
                BookingDate = b.BookingDate,
                NumberOfTickets = b.NumberOfTickets,
                TotalAmount = b.TotalAmount,
                Status = b.Status,
                UserId = b.UserId,
                ShowId = b.MovieShowId,
                NewDate = b.NewDate
            }).ToList();

            return Ok(results);
        }

        [HttpPost("with-seats")]
        public async Task<ActionResult<BookingDTO>> BookWithSeats(BookingWithSeatsDTO dto)
        {
            var booking = await _bookingService.CreateBookingWithTickets(dto.UserId, dto.ShowId, dto.SeatIds);

            var result = new BookingDTO
            {
                BookingId = booking.BookingId,
                BookingDate = booking.BookingDate,
                NumberOfTickets = booking.NumberOfTickets,
                TotalAmount = booking.TotalAmount,
                UserId = booking.UserId,
                ShowId = booking.MovieShowId,
                Status = booking.Status
            };

            return CreatedAtAction(nameof(GetBookingsByUserId), new { userId = dto.UserId }, result);
        }

        [HttpPut("{bookingId}/status")]
        public async Task<IActionResult> UpdateBookingStatus(int bookingId, BookingStatusUpdateDTO dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Status))
                return BadRequest("Status cannot be empty.");

            await _bookingService.UpdateBooking(bookingId, dto.Status);
            return NoContent();
        }

        [HttpPut("{bookingId}/reschedule")]
        public async Task<IActionResult> Reschedule(int bookingId, BookingRescheduleDTO dto)
        {
            if (dto.NewDate < DateTime.UtcNow)
                return BadRequest("New date must be in the future.");

            await _bookingService.Reschedule(bookingId, dto.NewDate);
            return NoContent();
        }

        [HttpDelete("{bookingId}")]
        public async Task<IActionResult> Delete(int bookingId)
        {
            var deleted = await _bookingService.DeleteBooking(bookingId);
            if (!deleted)
                return NotFound($"Booking with ID {bookingId} not found.");

            return NoContent();
        }
    }
}
