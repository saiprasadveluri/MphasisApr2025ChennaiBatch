﻿using Book.DTO;
using Book.Services;
using Microsoft.AspNetCore.Mvc;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShowController : ControllerBase
    {
        private readonly ShowService _showService;

        public ShowController(ShowService showService)
        {
            _showService = showService;
        }

        [HttpGet]
        public async Task<ActionResult<List<ShowDTO>>> GetAll()
        {
            var shows = await _showService.GetAllShowsAsync();
            return Ok(shows);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<ShowDTO>> GetById(int id)
        {
            var show = await _showService.GetShowByIdAsync(id);
            if (show == null) return NotFound();
            return Ok(show);
        }

        [HttpGet("theatre/{theatreId}")]
        public async Task<ActionResult<List<ShowDTO>>> GetByTheatre(int theatreId, [FromQuery] DateTime? date)
        {
            var shows = await _showService.GetShowsByTheatreAndDateAsync(theatreId, date);
            return Ok(shows);
        }

        [HttpPost]
        public async Task<ActionResult<ShowDTO>> Create(ShowDTO dto)
        {
            try
            {
                var created = await _showService.CreateShowAsync(dto);
                if (created == null) return BadRequest("Show not created.");
                return CreatedAtAction(nameof(GetById), new { id = created.ShowId }, created);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message);
            }
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<ShowDTO>> Update(int id, ShowDTO dto)
        {
            try
            {
                var updated = await _showService.UpdateShowAsync(id, dto);
                if (updated == null) return NotFound($"Show {id} not found.");
                return Ok(updated);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (InvalidOperationException ex)
            {
                return Conflict(ex.Message);
            }
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> Delete(int id)
        {
            var deleted = await _showService.DeleteShowAsync(id);
            if (!deleted) return NotFound();
            return NoContent();
        }
    }
}
