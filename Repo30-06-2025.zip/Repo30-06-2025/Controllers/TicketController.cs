﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TicketController : ControllerBase
    {
        private readonly TicketService _ticketService;

        public TicketController(TicketService ticketService)
        {
            _ticketService = ticketService;
        }

        [HttpGet]
        public async Task<ActionResult<List<TicketDTO>>> GetAllTickets()
        {
            var tickets = await _ticketService.GetAllTickets();
            return Ok(tickets);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TicketDTO>> GetTicketById(int id)
        {
            var ticket = await _ticketService.GetTicketById(id);
            if (ticket == null)
                return NotFound($"Ticket with ID {id} not found.");

            return Ok(ticket);
        }

        [HttpGet("ByBooking/{bookingId}")]
        public async Task<ActionResult<List<TicketDTO>>> GetTicketsByBookingId(int bookingId)
        {
            var tickets = await _ticketService.GetTicketsByBookingId(bookingId);
            return Ok(tickets);
        }

        [HttpPost]
        public async Task<ActionResult<TicketDTO>> CreateTicket([FromQuery] int bookingId, [FromQuery] int seatId)
        {
            var createdTicket = await _ticketService.CreateTicket(bookingId, seatId);
            return CreatedAtAction(nameof(GetTicketById), new { id = createdTicket.TicketId }, createdTicket);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<TicketDTO>> UpdateTicket(int id, [FromBody] TicketDTO ticketDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (ticketDto.TicketId != 0 && ticketDto.TicketId != id)
                return BadRequest("Ticket ID mismatch.");

            ticketDto.TicketId = id;
            var updatedTicket = await _ticketService.UpdateTicket(id, ticketDto);

            if (updatedTicket == null)
                return NotFound($"Ticket with ID {id} not found.");

            return Ok(updatedTicket);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteTicket(int id)
        {
            var success = await _ticketService.DeleteTicket(id);
            if (!success)
                return NotFound($"Ticket with ID {id} not found.");

            return NoContent();
        }
    }
}
