﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TheatreController : ControllerBase
    {
        private readonly TheatreService _theatreService;

        public TheatreController(TheatreService theatreService)
        {
            _theatreService = theatreService;
        }

        [HttpGet]
        public async Task<ActionResult<List<TheatreDTO>>> GetAllTheatres()
        {
            var theatres = await _theatreService.GetAllTheatres();
            return Ok(theatres);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<TheatreDTO>> GetTheatreById(int id)
        {
            var theatre = await _theatreService.GetTheatreById(id);
            if (theatre == null)
                return NotFound($"Theatre with ID {id} not found.");

            return Ok(theatre);
        }

        [HttpGet("ByCity/{cityId}")]
        public async Task<ActionResult<List<TheatreDTO>>> GetTheatresByCityId(int cityId)
        {
            var theatres = await _theatreService.GetTheatresByCityId(cityId);
            return Ok(theatres);
        }

        [HttpPost]
        public async Task<ActionResult<TheatreDTO>> CreateTheatre([FromBody] TheatreDTO theatreDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdTheatre = await _theatreService.CreateTheatre(theatreDto);
            return CreatedAtAction(nameof(GetTheatreById), new { id = createdTheatre.TheatreId }, createdTheatre);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<TheatreDTO>> UpdateTheatre(int id, [FromBody] TheatreDTO theatreDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (theatreDto.TheatreId != 0 && theatreDto.TheatreId != id)
                return BadRequest("Theatre ID in the URL does not match the request body.");

            theatreDto.TheatreId = id;
            var updatedTheatre = await _theatreService.UpdateTheatre(id, theatreDto);
            if (updatedTheatre == null)
                return NotFound($"Theatre with ID {id} not found.");

            return Ok(updatedTheatre);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteTheatre(int id)
        {
            var success = await _theatreService.DeleteTheatre(id);
            if (!success)
                return NotFound($"Theatre with ID {id} not found.");

            return NoContent();
        }
    }
}
