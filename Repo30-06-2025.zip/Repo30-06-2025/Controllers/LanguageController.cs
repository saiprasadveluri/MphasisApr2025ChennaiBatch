﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LanguageController : ControllerBase
    {
        private readonly LanguageService _languageService;

        public LanguageController(LanguageService languageService)
        {
            _languageService = languageService;
        }

        [HttpGet]
        public async Task<ActionResult<List<LanguageDTO>>> GetAllLanguages()
        {
            var languages = await _languageService.GetAllLanguages();
            return Ok(languages);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<LanguageDTO>> GetLanguageById(int id)
        {
            var language = await _languageService.GetLanguageById(id);
            if (language == null)
                return NotFound($"Language with ID {id} not found.");

            return Ok(language);
        }

        [HttpPost]
        public async Task<ActionResult<LanguageDTO>> CreateLanguage(LanguageDTO languageDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdLanguage = await _languageService.CreateLanguage(languageDto);
            return CreatedAtAction(nameof(GetLanguageById), new { id = createdLanguage.LanguageId }, createdLanguage);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<LanguageDTO>> UpdateLanguage(int id, LanguageDTO languageDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (languageDto.LanguageId != 0 && languageDto.LanguageId != id)
                return BadRequest("Language ID in the URL does not match the request body.");

            languageDto.LanguageId = id;
            var updatedLanguage = await _languageService.UpdateLanguage(id, languageDto);

            if (updatedLanguage == null)
                return NotFound($"Language with ID {id} not found.");

            return Ok(updatedLanguage);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteLanguage(int id)
        {
            var success = await _languageService.DeleteLanguage(id);
            if (!success)
                return NotFound($"Language with ID {id} not found.");

            return NoContent();
        }
    }
}
