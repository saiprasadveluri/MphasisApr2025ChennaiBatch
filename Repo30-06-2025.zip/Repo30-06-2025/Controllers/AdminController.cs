﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly AdminService _adminService;

        public AdminController(AdminService adminService)
        {
            _adminService = adminService;
        }

        [HttpGet]
        public async Task<ActionResult<List<AdminDTO>>> GetAllAdmins()
        {
            var admins = await _adminService.GetAllAdmins();
            return Ok(admins);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<AdminDTO>> GetAdminById(int id)
        {
            var admin = await _adminService.GetAdminById(id);
            if (admin == null)
                return NotFound($"Admin with ID {id} not found.");

            return Ok(admin);
        }

        [HttpPost]
        public async Task<ActionResult<AdminDTO>> AddAdmin(AdminDTO adminCreateDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdAdmin = await _adminService.AddAdmin(adminCreateDto);
            return CreatedAtAction(nameof(GetAdminById), new { id = createdAdmin.AdminId }, createdAdmin);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<AdminDTO>> UpdateAdmin(int id, AdminDTO adminUpdateDto)
        {
            if (adminUpdateDto.AdminId != id)
                return BadRequest("No Admin Found with Given ID");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var updatedAdmin = await _adminService.UpdateAdmin(id, adminUpdateDto);
            if (updatedAdmin == null)
                return NotFound($"Admin with ID {id} not found or update failed.");

            return Ok(updatedAdmin);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteAdmin(int id)
        {
            var success = await _adminService.DeleteAdmin(id);
            if (!success)
                return NotFound($"Admin with ID {id} not found.");

            return NoContent();
        }

        [HttpPost("login")]
        public async Task<ActionResult<AdminDTO>> Login(AdminDTO adminLoginDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var admin = await _adminService.VerifyAdminCredentials(adminLoginDto.AdminName, adminLoginDto.Password);
            if (admin == null)
                return Unauthorized("Invalid credentials.");

            return Ok(new { Message = "Login successful!", Admin = admin });
        }
    }
}
