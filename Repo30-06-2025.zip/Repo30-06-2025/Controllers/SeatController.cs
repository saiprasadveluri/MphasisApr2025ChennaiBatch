﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeatController : ControllerBase
    {
        private readonly SeatService _seatService;

        public SeatController(SeatService seatService)
        {
            _seatService = seatService;
        }

        [HttpGet]
        public async Task<ActionResult<List<SeatDTO>>> GetAllSeats()
        {
            var seats = await _seatService.GetAllSeats();
            return Ok(seats);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<SeatDTO>> GetSeatById(int id)
        {
            var seat = await _seatService.GetSeatById(id);
            if (seat == null)
                return NotFound($"Seat with ID {id} not found.");

            return Ok(seat);
        }

        [HttpGet("ByTheatre/{theatreId}")]
        public async Task<ActionResult<List<SeatDTO>>> GetSeatsByTheatreId(int theatreId)
        {
            var seats = await _seatService.GetSeatsByTheatreId(theatreId);
            return Ok(seats);
        }

        [HttpPost]
        public async Task<ActionResult<SeatDTO>> CreateSeat( SeatDTO seatDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdSeat = await _seatService.CreateSeat(seatDto);
            return CreatedAtAction(nameof(GetSeatById), new { id = createdSeat.SeatId }, createdSeat);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<SeatDTO>> UpdateSeat(int id, SeatDTO seatDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (seatDto.SeatId != 0 && seatDto.SeatId != id)
                return BadRequest("Seat ID in the URL does not match the request body.");

            seatDto.SeatId = id;
            var updatedSeat = await _seatService.UpdateSeat(id, seatDto);
            if (updatedSeat == null)
                return NotFound($"Seat with ID {id} not found.");

            return Ok(updatedSeat);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteSeat(int id)
        {
            var success = await _seatService.DeleteSeat(id);
            if (!success)
                return NotFound($"Seat with ID {id} not found.");

            return NoContent();
        }
    }
}
