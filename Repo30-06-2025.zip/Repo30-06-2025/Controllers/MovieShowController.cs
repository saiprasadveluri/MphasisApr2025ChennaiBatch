﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieShowController : ControllerBase
    {
        private readonly MovieShowService _movieShowService;

        public MovieShowController(MovieShowService movieShowService)
        {
            _movieShowService = movieShowService;
        }

        [HttpGet]
        public async Task<ActionResult<List<MovieShowDTO>>> GetAllMovieShows()
        {
            var movieShows = await _movieShowService.GetAllMovieShowsIdOnly();
            return Ok(movieShows);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<MovieShowDTO>> GetMovieShowById(int id)
        {
            var movieShow = await _movieShowService.GetMovieShowIdOnlyById(id);
            if (movieShow == null)
                return NotFound($"Movie Show with ID {id} not found.");

            return Ok(movieShow);
        }

        [HttpGet("ByMovie/{movieId}")]
        public async Task<ActionResult<List<MovieShowDTO>>> GetMovieShowsByMovieId(int movieId)
        {
            var movieShows = await _movieShowService.GetMovieShowsIdOnlyByMovieId(movieId);
            return Ok(movieShows);
        }

        [HttpGet("ByShow/{showId}")]
        public async Task<ActionResult<List<MovieShowDTO>>> GetMovieShowsByShowId(int showId)
        {
            var movieShows = await _movieShowService.GetMovieShowsIdOnlyByShowId(showId);
            return Ok(movieShows);
        }

        [HttpPost]
        public async Task<ActionResult<MovieShowDTO>> AddMovieShow(MovieShowDTO movieShowDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var created = await _movieShowService.AddMovieShow(movieShowDto);
            return CreatedAtAction(nameof(GetMovieShowById), new { id = created.MovieShowId }, created);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<MovieShowDTO>> UpdateMovieShow(int id, MovieShowDTO movieShowDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (movieShowDto.MovieShowId != 0 && movieShowDto.MovieShowId != id)
                return BadRequest("Movie Show ID in the URL does not match the request body.");

            movieShowDto.MovieShowId = id;
            var updated = await _movieShowService.UpdateMovieShow(id, movieShowDto);

            if (updated == null)
                return NotFound($"Movie Show with ID {id} not found.");

            return Ok(updated);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteMovieShow(int id)
        {
            var success = await _movieShowService.DeleteMovieShow(id);
            if (!success)
                return NotFound($"Movie Show with ID {id} not found.");

            return NoContent();
        }
    }
}
