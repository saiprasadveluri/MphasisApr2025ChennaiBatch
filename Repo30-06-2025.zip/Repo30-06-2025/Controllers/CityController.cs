﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly CityService _cityService;

        public CityController(CityService cityService)
        {
            _cityService = cityService;
        }

        [HttpGet]
        public async Task<ActionResult<List<CityDTO>>> GetAllCities()
        {
            var cities = await _cityService.GetAllCities();
            return Ok(cities);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<CityDTO>> GetCityById(int id)
        {
            var city = await _cityService.GetCityById(id);
            if (city == null)
                return NotFound($"City with ID {id} not found.");

            return Ok(city);
        }

        [HttpPost]
        public async Task<ActionResult<CityDTO>> AddCity(CityDTO cityDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdCity = await _cityService.AddCity(cityDto);
            return CreatedAtAction(nameof(GetCityById), new { id = createdCity.CityId }, createdCity);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<CityDTO>> UpdateCity(int id, CityDTO cityDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (cityDto.CityId != 0 && cityDto.CityId != id)
                return BadRequest("City ID in the URL does not match the ID in the request body.");

            cityDto.CityId = id;
            var updatedCity = await _cityService.UpdateCity(id, cityDto);
            if (updatedCity == null)
                return NotFound($"City with ID {id} not found.");

            return Ok(updatedCity);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteCity(int id)
        {
            var success = await _cityService.DeleteCity(id);
            if (!success)
                return NotFound($"City with ID {id} not found.");

            return NoContent();
        }
    }
}
