﻿using Microsoft.AspNetCore.Mvc;
using Book.DTO;
using Book.Services;

namespace Book.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly MovieService _movieService;

        public MovieController(MovieService movieService)
        {
            _movieService = movieService;
        }

        [HttpGet]
        public async Task<ActionResult<List<MovieDTO>>> GetAllMovies()
        {
            var movies = await _movieService.GetAllMovies();
            return Ok(movies);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<MovieDTO>> GetMovieById(int id)
        {
            var movie = await _movieService.GetMovieById(id);
            if (movie == null)
                return NotFound($"Movie with ID {id} not found.");

            return Ok(movie);
        }

        [HttpPost]
        public async Task<ActionResult<MovieDTO>> Add(MovieDTO movieDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var createdMovie = await _movieService.Add(movieDto);
            return CreatedAtAction(nameof(GetMovieById), new { id = createdMovie.MovieId }, createdMovie);
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<MovieDTO>> UpdateMovie(int id,MovieDTO movieDto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            if (movieDto.MovieId != 0 && movieDto.MovieId != id)
                return BadRequest("Movie ID in the URL does not match the request body.");

            movieDto.MovieId = id;
            var updatedMovie = await _movieService.UpdateMovie(id, movieDto);

            if (updatedMovie == null)
                return NotFound($"Movie with ID {id} not found.");

            return Ok(updatedMovie);
        }

        [HttpDelete("{id}")]
        public async Task<ActionResult> DeleteMovie(int id)
        {
            var success = await _movieService.DeleteMovie(id);
            if (!success)
                return NotFound($"Movie with ID {id} not found.");

            return NoContent();
        }
    }
}
