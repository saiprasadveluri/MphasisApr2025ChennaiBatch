﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class ShowService
    {
        private readonly BookMyShowDbContext _context;

        public ShowService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<ShowDTO>> GetAllShowsAsync() =>
            await _context.Shows
                .Select(s => new ShowDTO
                {
                    ShowId = s.ShowId,
                    ShowDate = s.ShowDate,
                    ShowTime = s.ShowTime,
                    AvailableSeates = s.AvailableSeates,
                    Price = s.Price,
                    TheatreId = s.TheatreId
                })
                .ToListAsync();

        public async Task<ShowDTO?> GetShowByIdAsync(int id)
        {
            var show = await _context.Shows.FindAsync(id);
            return show == null ? null : new ShowDTO
            {
                ShowId = show.ShowId,
                ShowDate = show.ShowDate,
                ShowTime = show.ShowTime,
                AvailableSeates = show.AvailableSeates,
                Price = show.Price,
                TheatreId = show.TheatreId
            };
        }

        public async Task<List<ShowDTO>> GetShowsByTheatreAndDateAsync(int theatreId, DateTime? date = null)
        {
            var query = _context.Shows.Where(s => s.TheatreId == theatreId);

            if (date.HasValue)
                query = query.Where(s => s.ShowDate.Date == date.Value.Date);

            return await query
                .OrderBy(s => s.ShowDate)
                .ThenBy(s => s.ShowTime)
                .Select(s => new ShowDTO
                {
                    ShowId = s.ShowId,
                    ShowDate = s.ShowDate,
                    ShowTime = s.ShowTime,
                    AvailableSeates = s.AvailableSeates,
                    Price = s.Price,
                    TheatreId = s.TheatreId
                })
                .ToListAsync();
        }

        public async Task<ShowDTO?> CreateShowAsync(ShowDTO dto)
        {
            if (dto.ShowDate == default)
                throw new ArgumentException("ShowDate cannot be default.");

            if (dto.AvailableSeates < 0)
                throw new ArgumentException("AvailableSeats cannot be negative.");

            if (dto.Price < 0)
                throw new ArgumentException("Price cannot be negative.");

            if (dto.TheatreId <= 0)
                throw new ArgumentException("Invalid TheatreId.");

            var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == dto.TheatreId);
            if (!theatreExists)
                throw new ArgumentException($"Theatre with ID {dto.TheatreId} does not exist.");

            var duplicate = await _context.Shows.AnyAsync(s =>
                s.TheatreId == dto.TheatreId &&
                s.ShowDate.Date == dto.ShowDate.Date &&
                s.ShowTime == dto.ShowTime);

            if (duplicate)
                throw new InvalidOperationException($"Show already exists for Theatre {dto.TheatreId} at {dto.ShowDate:d} {dto.ShowTime}.");

            var show = new Show
            {
                ShowDate = dto.ShowDate.Date,
                ShowTime = dto.ShowTime,
                AvailableSeates = dto.AvailableSeates,
                Price = dto.Price,
                TheatreId = dto.TheatreId
            };

            _context.Shows.Add(show);
            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new ShowDTO
            {
                ShowId = show.ShowId,
                ShowDate = show.ShowDate,
                ShowTime = show.ShowTime,
                AvailableSeates = show.AvailableSeates,
                Price = show.Price,
                TheatreId = show.TheatreId
            } : null;
        }

        public async Task<ShowDTO?> UpdateShowAsync(int id, ShowDTO dto)
        {
            var show = await _context.Shows.FindAsync(id);
            if (show == null) return null;

            if (dto.ShowDate == default)
                throw new ArgumentException("ShowDate cannot be default.");

            if (dto.AvailableSeates < 0)
                throw new ArgumentException("AvailableSeats cannot be negative.");

            if (dto.Price < 0)
                throw new ArgumentException("Price cannot be negative.");

            if (dto.TheatreId <= 0)
                throw new ArgumentException("Invalid TheatreId.");

            if (show.TheatreId != dto.TheatreId)
            {
                var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == dto.TheatreId);
                if (!theatreExists)
                    throw new InvalidOperationException("Specified TheatreId does not exist.");
            }

            var duplicate = await _context.Shows.AnyAsync(s =>
                s.TheatreId == dto.TheatreId &&
                s.ShowDate.Date == dto.ShowDate.Date &&
                s.ShowTime == dto.ShowTime &&
                s.ShowId != id);

            if (duplicate)
                throw new InvalidOperationException($"Show already exists for Theatre {dto.TheatreId} at {dto.ShowDate:d} {dto.ShowTime}.");

            show.ShowDate = dto.ShowDate.Date;
            show.ShowTime = dto.ShowTime;
            show.AvailableSeates = dto.AvailableSeates;
            show.Price = dto.Price;
            show.TheatreId = dto.TheatreId;

            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new ShowDTO
            {
                ShowId = show.ShowId,
                ShowDate = show.ShowDate,
                ShowTime = show.ShowTime,
                AvailableSeates = show.AvailableSeates,
                Price = show.Price,
                TheatreId = show.TheatreId
            } : null;
        }

        public async Task<bool> DeleteShowAsync(int id)
        {
            var show = await _context.Shows.FindAsync(id);
            if (show == null) return false;

            _context.Shows.Remove(show);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
