﻿using Book.Data; 
using Book.Data.DB; 
using Book.DTO; 
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity; 


namespace Book.Services
{
    public class AdminService
    {
        private readonly BookMyShowDbContext _context;
        private readonly IPasswordHasher<Admin> _passwordHasher; 

        public AdminService(BookMyShowDbContext context, IPasswordHasher<Admin> passwordHasher)
        {
            _context = context;
            _passwordHasher = passwordHasher; 
        }

        // List of all Admins
        public async Task<List<AdminDTO>> GetAllAdmins()
        {
            return await _context.Admins 
                                 .Select(a => new AdminDTO
                                 {
                                     AdminId = a.AdminId,
                                     AdminName = a.AdminName
                                 })
                                 .ToListAsync();
        }

        // Getting Admin by ID
        public async Task<AdminDTO?> GetAdminById(int id) 
        {
            var admin = await _context.Admins.FindAsync(id); 

            if (admin == null)
            {
                return null;
            }

            return new AdminDTO
            {
                AdminId = admin.AdminId,
                AdminName = admin.AdminName
            };
        }

        // Add Admin
        public async Task<AdminDTO?> AddAdmin(AdminDTO adminCreateDto) 
        {
            
            if (string.IsNullOrWhiteSpace(adminCreateDto.AdminName))
            {
                throw new ArgumentException("Admin name cannot be empty or whitespace.", nameof(adminCreateDto.AdminName));
            }
            if (string.IsNullOrWhiteSpace(adminCreateDto.Password) || adminCreateDto.Password.Length < 6)
            {
                throw new ArgumentException("Password must be at least 6 characters long.", nameof(adminCreateDto.Password));
            }

         
            var existingAdmin = await _context.Admins.AnyAsync(a => a.AdminName == adminCreateDto.AdminName);
            if (existingAdmin)
            {
                throw new InvalidOperationException($"Admin with name '{adminCreateDto.AdminName}' already exists.");
            }

            // Hash Pasword 
            string hashedPassword = _passwordHasher.HashPassword(new Admin(), adminCreateDto.Password);

            var admin = new Admin
            {
                AdminName = adminCreateDto.AdminName,
                Password = hashedPassword 
            };

            _context.Admins.Add(admin); 
            int savedChanges = await _context.SaveChangesAsync(); 

            if (savedChanges > 0)
            {
                return new AdminDTO
                {
                    AdminId = admin.AdminId,
                    AdminName = admin.AdminName
                };
            }
            return null; 
        }

        //Update
        public async Task<AdminDTO?> UpdateAdmin(int id, AdminDTO adminUpdateDto) // Changed return type to AdminDTO?
        {
            var existingAdmin = await _context.Admins.FindAsync(id);

            if (existingAdmin == null)
            {
                return null;
            }

            if (string.IsNullOrWhiteSpace(adminUpdateDto.AdminName))
            {
                throw new ArgumentException("Admin name cannot be empty or whitespace for update.", nameof(adminUpdateDto.AdminName));
            }

            
            if (existingAdmin.AdminName != adminUpdateDto.AdminName)
            {
                var nameTaken = await _context.Admins.AnyAsync(a => a.AdminName == adminUpdateDto.AdminName && a.AdminId != id);
                if (nameTaken)
                {
                    throw new InvalidOperationException($"Admin name '{adminUpdateDto.AdminName}' is already taken by another admin.");
                }
            }

            existingAdmin.AdminName = adminUpdateDto.AdminName;

            _context.Entry(existingAdmin).State = EntityState.Modified;
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new AdminDTO
                {
                    AdminId = existingAdmin.AdminId,
                    AdminName = existingAdmin.AdminName
                };
            }
            return null;
        }

        //Delete
        public async Task<bool> DeleteAdmin(int id)
        {
            var adminToDelete = await _context.Admins.FindAsync(id); 
            if (adminToDelete == null)
            {
                return false; 
            }

            _context.Admins.Remove(adminToDelete);
            int savedChanges = await _context.SaveChangesAsync(); 

            return savedChanges > 0;
        }

        // Credential Verification 
        public async Task<AdminDTO?> VerifyAdminCredentials(string adminName, string plainTextPassword) // Changed return type to AdminDTO?
        {
            if (string.IsNullOrWhiteSpace(adminName) || string.IsNullOrWhiteSpace(plainTextPassword))
            {
                return null;
            }

            var admin = await _context.Admins.FirstOrDefaultAsync(a => a.AdminName == adminName);

            if (admin == null)
            {
                return null; 
            }

           
            var verificationResult = _passwordHasher.VerifyHashedPassword(admin, admin.Password, plainTextPassword);

            if (verificationResult == PasswordVerificationResult.Success ||
                verificationResult == PasswordVerificationResult.SuccessRehashNeeded)
            {
                if (verificationResult == PasswordVerificationResult.SuccessRehashNeeded)
                {
                    admin.Password = _passwordHasher.HashPassword(admin, plainTextPassword);
                    await _context.SaveChangesAsync();
                }

                return new AdminDTO
                {
                    AdminId = admin.AdminId,
                    AdminName = admin.AdminName
                };
            }
            return null; 
        }
    }
}