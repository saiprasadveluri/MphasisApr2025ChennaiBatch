﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class LanguageService
    {
        private readonly BookMyShowDbContext _context;

        public LanguageService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<LanguageDTO>> GetAllLanguages() =>
            await _context.Languages
                .Select(l => new LanguageDTO
                {
                    LanguageId = l.LanguageId,
                    LanguageName = l.LanguageName
                })
                .ToListAsync();

        public async Task<LanguageDTO?> GetLanguageById(int id)
        {
            var language = await _context.Languages.FindAsync(id);
            return language == null
                ? null
                : new LanguageDTO
                {
                    LanguageId = language.LanguageId,
                    LanguageName = language.LanguageName
                };
        }

        public async Task<LanguageDTO?> CreateLanguage(LanguageDTO languageDto)
        {
            if (string.IsNullOrWhiteSpace(languageDto.LanguageName))
                throw new ArgumentException("Language name cannot be empty.", nameof(languageDto.LanguageName));

            if (await _context.Languages.AnyAsync(l => l.LanguageName == languageDto.LanguageName))
                throw new InvalidOperationException($"Language '{languageDto.LanguageName}' already exists.");

            var language = new Language { LanguageName = languageDto.LanguageName };
            _context.Languages.Add(language);
            var saved = await _context.SaveChangesAsync();

            return saved > 0
                ? new LanguageDTO
                {
                    LanguageId = language.LanguageId,
                    LanguageName = language.LanguageName
                }
                : null;
        }

        public async Task<LanguageDTO?> UpdateLanguage(int id, LanguageDTO languageDto)
        {
            var existing = await _context.Languages.FindAsync(id);
            if (existing == null) return null;

            if (string.IsNullOrWhiteSpace(languageDto.LanguageName))
                throw new ArgumentException("Language name cannot be empty.", nameof(languageDto.LanguageName));

            if (existing.LanguageName != languageDto.LanguageName)
            {
                var taken = await _context.Languages.AnyAsync(l =>
                    l.LanguageName == languageDto.LanguageName && l.LanguageId != id);
                if (taken)
                    throw new InvalidOperationException($"Language name '{languageDto.LanguageName}' is already taken.");
            }

            existing.LanguageName = languageDto.LanguageName;
            var saved = await _context.SaveChangesAsync();

            return saved > 0
                ? new LanguageDTO
                {
                    LanguageId = existing.LanguageId,
                    LanguageName = existing.LanguageName
                }
                : null;
        }

        public async Task<bool> DeleteLanguage(int id)
        {
            var language = await _context.Languages.FindAsync(id);
            if (language == null) return false;

            _context.Languages.Remove(language);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
