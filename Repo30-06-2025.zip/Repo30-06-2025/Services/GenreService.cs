﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class GenreService
    {
        private readonly BookMyShowDbContext _context;

        public GenreService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<GenreDTO>> GetAllGenres() =>
            await _context.Genres
                .Select(g => new GenreDTO
                {
                    GenreId = g.GenreId,
                    GenreName = g.GenreName
                })
                .ToListAsync();

        public async Task<GenreDTO?> GetGenreById(int id)
        {
            var genre = await _context.Genres.FindAsync(id);
            return genre == null
                ? null
                : new GenreDTO
                {
                    GenreId = genre.GenreId,
                    GenreName = genre.GenreName
                };
        }

        public async Task<GenreDTO?> Add(GenreDTO genreDto)
        {
            if (string.IsNullOrWhiteSpace(genreDto.GenreName))
                throw new ArgumentException("Genre name cannot be empty.", nameof(genreDto.GenreName));

            if (await _context.Genres.AnyAsync(g => g.GenreName == genreDto.GenreName))
                throw new InvalidOperationException($"Genre '{genreDto.GenreName}' already exists.");

            var genre = new Genre { GenreName = genreDto.GenreName };
            _context.Genres.Add(genre);
            var saved = await _context.SaveChangesAsync();

            return saved > 0
                ? new GenreDTO { GenreId = genre.GenreId, GenreName = genre.GenreName }
                : null;
        }

        public async Task<GenreDTO?> UpdateGenre(int id, GenreDTO genreDto)
        {
            var existing = await _context.Genres.FindAsync(id);
            if (existing == null) return null;

            if (string.IsNullOrWhiteSpace(genreDto.GenreName))
                throw new ArgumentException("Genre name cannot be empty.", nameof(genreDto.GenreName));

            if (existing.GenreName != genreDto.GenreName)
            {
                var taken = await _context.Genres.AnyAsync(g => g.GenreName == genreDto.GenreName && g.GenreId != id);
                if (taken)
                    throw new InvalidOperationException($"Genre '{genreDto.GenreName}' already exists.");
            }

            existing.GenreName = genreDto.GenreName;
            var saved = await _context.SaveChangesAsync();

            return saved > 0
                ? new GenreDTO { GenreId = existing.GenreId, GenreName = existing.GenreName }
                : null;
        }

        public async Task<bool> DeleteGenre(int id)
        {
            var genre = await _context.Genres.FindAsync(id);
            if (genre == null) return false;

            _context.Genres.Remove(genre);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
