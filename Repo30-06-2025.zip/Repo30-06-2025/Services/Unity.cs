﻿using Book.Data.DB;
using Microsoft.AspNetCore.Identity; 

namespace Book.Services
{
    public class Unity 
    {
        private readonly BookMyShowDbContext _context;
        private readonly IPasswordHasher<Book.Data.User> _userPasswordHasher;
        private readonly IPasswordHasher<Book.Data.Admin> _adminPasswordHasher;

        private AdminService? _adminService;
        private BookingService? _bookingService;
        private CityService? _cityService;
        private GenreService? _genreService;
        private LanguageService? _languageService;
        private MovieService? _movieService;
        private ReviewService? _reviewService;
        private SeatService? _seatService;
        private ShowService? _showService;
        private TheatreService? _theatreService;
        private TicketService? _ticketService;
        private UserService? _userService;
        private MovieShowService? _movieShowService;

        public Unity(
            BookMyShowDbContext context,
            IPasswordHasher<Book.Data.User> userPasswordHasher,
            IPasswordHasher<Book.Data.Admin> adminPasswordHasher)
        {
            _context = context;
            _userPasswordHasher = userPasswordHasher;
            _adminPasswordHasher = adminPasswordHasher;
        }
        public AdminService AdminService
        {
            get
            {
                if (_adminService == null)
                {
                    _adminService = new AdminService(_context, _adminPasswordHasher);
                }
                return _adminService;
            }
        }

        public BookingService BookingService
        {
            get
            {
                if (_bookingService == null)
                {
                    _bookingService = new BookingService(_context);
                }
                return _bookingService;
            }
        }
        public CityService CityService
        {
            get
            {
                if (_cityService == null)
                {
                    _cityService = new CityService(_context);
                }
                return _cityService;
            }
        }

        public GenreService GenreService
        {
            get
            {
                if (_genreService == null)
                {
                    _genreService = new GenreService(_context);
                }
                return _genreService;
            }
        }

        public LanguageService LanguageService
        {
            get
            {
                if (_languageService == null)
                {
                    _languageService = new LanguageService(_context);
                }
                return _languageService;
            }
        }
        public MovieService MovieService
        {
            get
            {
                if (_movieService == null)
                {
                    _movieService = new MovieService(_context);
                }
                return _movieService;
            }
        }

        public ReviewService ReviewService
        {
            get
            {
                if (_reviewService == null)
                {
                    _reviewService = new ReviewService(_context);
                }
                return _reviewService;
            }
        }

        public SeatService SeatService
        {
            get
            {
                if (_seatService == null)
                {
                    _seatService = new SeatService(_context);
                }
                return _seatService;
            }
        }

        public ShowService ShowService
        {
            get
            {
                if (_showService == null)
                {
                    _showService = new ShowService(_context);
                }
                return _showService;
            }
        }

        public TheatreService TheatreService
        {
            get
            {
                if (_theatreService == null)
                {
                    _theatreService = new TheatreService(_context);
                }
                return _theatreService;
            }
        }
         public TicketService GetTicketService()
        {
            if (_ticketService == null)
            {
                _ticketService = new TicketService(_context);
            }
            return _ticketService;
        }

        public UserService UserService
        {
            get
            {
                if (_userService == null)
                {
                    _userService = new UserService(_context, _userPasswordHasher);
                }
                return _userService;
            }
        }
        public MovieShowService MovieShowService
        {
            get
            {
                if (_movieShowService == null)
                {
                    _movieShowService = new MovieShowService(_context);
                }
                return _movieShowService;
            }
        }
        public async Task<int> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync();
        }
    }
}