﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class MovieShowService
    {
        private readonly BookMyShowDbContext _context;

        public MovieShowService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<MovieShowDTO>> GetAllMovieShowsIdOnly() =>
            await _context.MovieShows
                .Select(ms => new MovieShowDTO
                {
                    MovieShowId = ms.MovieShowId,
                    MovieId = ms.MovieId,
                    ShowId = ms.ShowId,
                    TheatreId = ms.TheatreId
                })
                .ToListAsync();

        public async Task<MovieShowDTO?> GetMovieShowIdOnlyById(int id)
        {
            var movieShow = await _context.MovieShows
                .AsNoTracking()
                .FirstOrDefaultAsync(ms => ms.MovieShowId == id);

            return movieShow == null ? null : new MovieShowDTO
            {
                MovieShowId = movieShow.MovieShowId,
                MovieId = movieShow.MovieId,
                ShowId = movieShow.ShowId,
                TheatreId = movieShow.TheatreId
            };
        }

        public async Task<List<MovieShowDTO>> GetMovieShowsIdOnlyByMovieId(int movieId) =>
            await _context.MovieShows
                .AsNoTracking()
                .Where(ms => ms.MovieId == movieId)
                .Select(ms => new MovieShowDTO
                {
                    MovieShowId = ms.MovieShowId,
                    MovieId = ms.MovieId,
                    ShowId = ms.ShowId,
                    TheatreId = ms.TheatreId
                })
                .ToListAsync();

        public async Task<List<MovieShowDTO>> GetMovieShowsIdOnlyByShowId(int showId) =>
            await _context.MovieShows
                .AsNoTracking()
                .Where(ms => ms.ShowId == showId)
                .Select(ms => new MovieShowDTO
                {
                    MovieShowId = ms.MovieShowId,
                    MovieId = ms.MovieId,
                    ShowId = ms.ShowId,
                    TheatreId = ms.TheatreId
                })
                .ToListAsync();

        public async Task<MovieShowDTO> AddMovieShow(MovieShowDTO dto)
        {
            if (dto == null)
                throw new ArgumentNullException(nameof(dto));

            var movieExists = await _context.Movies.AnyAsync(m => m.MovieId == dto.MovieId);
            var showExists = await _context.Shows.AnyAsync(s => s.ShowId == dto.ShowId);
            var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == dto.TheatreId);
            if (!movieExists || !showExists || !theatreExists)
                throw new InvalidOperationException("Invalid foreign key references.");

            var exists = await _context.MovieShows.AnyAsync(ms =>
                ms.MovieId == dto.MovieId &&
                ms.ShowId == dto.ShowId &&
                ms.TheatreId == dto.TheatreId);
            if (exists)
                throw new InvalidOperationException("Duplicate MovieShow combination.");

            var movieShow = new MovieShow
            {
                MovieId = dto.MovieId,
                ShowId = dto.ShowId,
                TheatreId = dto.TheatreId
            };

            _context.MovieShows.Add(movieShow);
            await _context.SaveChangesAsync();

            return new MovieShowDTO
            {
                MovieShowId = movieShow.MovieShowId,
                MovieId = movieShow.MovieId,
                ShowId = movieShow.ShowId,
                TheatreId = movieShow.TheatreId
            };
        }

        public async Task<MovieShowDTO?> UpdateMovieShow(int id, MovieShowDTO dto)
        {
            var existing = await _context.MovieShows.FindAsync(id);
            if (existing == null || dto == null) return null;

            if (existing.MovieId != dto.MovieId &&
                !await _context.Movies.AnyAsync(m => m.MovieId == dto.MovieId))
                throw new InvalidOperationException("Invalid MovieId.");

            if (existing.ShowId != dto.ShowId &&
                !await _context.Shows.AnyAsync(s => s.ShowId == dto.ShowId))
                throw new InvalidOperationException("Invalid ShowId.");

            if (existing.TheatreId != dto.TheatreId &&
                !await _context.Theatres.AnyAsync(t => t.TheatreId == dto.TheatreId))
                throw new InvalidOperationException("Invalid TheatreId.");

            var duplicate = await _context.MovieShows.AnyAsync(ms =>
                ms.MovieId == dto.MovieId &&
                ms.ShowId == dto.ShowId &&
                ms.TheatreId == dto.TheatreId &&
                ms.MovieShowId != id);
            if (duplicate)
                throw new InvalidOperationException("Duplicate MovieShow combination exists.");

            existing.MovieId = dto.MovieId;
            existing.ShowId = dto.ShowId;
            existing.TheatreId = dto.TheatreId;

            await _context.SaveChangesAsync();

            return new MovieShowDTO
            {
                MovieShowId = existing.MovieShowId,
                MovieId = existing.MovieId,
                ShowId = existing.ShowId,
                TheatreId = existing.TheatreId
            };
        }

        public async Task<bool> DeleteMovieShow(int id)
        {
            var movieShow = await _context.MovieShows.FindAsync(id);
            if (movieShow == null) return false;

            var hasBookings = await _context.Bookings.AnyAsync(b => b.MovieShowId == id);
            if (hasBookings)
                throw new InvalidOperationException("MovieShow has associated bookings.");

            _context.MovieShows.Remove(movieShow);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
