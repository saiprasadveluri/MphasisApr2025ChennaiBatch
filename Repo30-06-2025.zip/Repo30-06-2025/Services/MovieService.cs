﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class MovieService
    {
        private readonly BookMyShowDbContext _context;

        public MovieService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<MovieDTO>> GetAllMovies() =>
            await _context.Movies
                .Select(m => new MovieDTO
                {
                    MovieId = m.MovieId,
                    Title = m.Title,
                    Description = m.Description,
                    GenreId = m.GenreId,
                    ReleaseDate = m.ReleaseDate
                })
                .ToListAsync();

        public async Task<MovieDTO?> GetMovieById(int id)
        {
            var movie = await _context.Movies.FindAsync(id);
            return movie == null ? null : new MovieDTO
            {
                MovieId = movie.MovieId,
                Title = movie.Title,
                Description = movie.Description,
                GenreId = movie.GenreId,
                ReleaseDate = movie.ReleaseDate
            };
        }

        public async Task<MovieDTO?> Add(MovieDTO movieDto)
        {
            if (string.IsNullOrWhiteSpace(movieDto.Title))
                throw new ArgumentException("Movie title cannot be empty.", nameof(movieDto.Title));

            if (movieDto.GenreId <= 0)
                throw new ArgumentException("Invalid GenreId.", nameof(movieDto.GenreId));

            var genreExists = await _context.Genres.AnyAsync(g => g.GenreId == movieDto.GenreId);
            if (!genreExists)
                throw new ArgumentException($"Genre ID {movieDto.GenreId} does not exist.", nameof(movieDto.GenreId));

            var movie = new Movie
            {
                Title = movieDto.Title,
                Description = movieDto.Description,
                GenreId = movieDto.GenreId,
                ReleaseDate = movieDto.ReleaseDate
            };

            _context.Movies.Add(movie);
            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new MovieDTO
            {
                MovieId = movie.MovieId,
                Title = movie.Title,
                Description = movie.Description,
                GenreId = movie.GenreId,
                ReleaseDate = movie.ReleaseDate
            } : null;
        }

        public async Task<MovieDTO?> UpdateMovie(int id, MovieDTO movieDto)
        {
            var existing = await _context.Movies.FindAsync(id);
            if (existing == null) return null;

            if (string.IsNullOrWhiteSpace(movieDto.Title))
                throw new ArgumentException("Movie title cannot be empty.", nameof(movieDto.Title));

            if (movieDto.GenreId <= 0)
                throw new ArgumentException("Invalid GenreId.", nameof(movieDto.GenreId));

            if (existing.GenreId != movieDto.GenreId)
            {
                var genreExists = await _context.Genres.AnyAsync(g => g.GenreId == movieDto.GenreId);
                if (!genreExists)
                    throw new ArgumentException($"Genre ID {movieDto.GenreId} does not exist.", nameof(movieDto.GenreId));
            }

            existing.Title = movieDto.Title;
            existing.Description = movieDto.Description;
            existing.GenreId = movieDto.GenreId;
            existing.ReleaseDate = movieDto.ReleaseDate;

            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new MovieDTO
            {
                MovieId = existing.MovieId,
                Title = existing.Title,
                Description = existing.Description,
                GenreId = existing.GenreId,
                ReleaseDate = existing.ReleaseDate
            } : null;
        }

        public async Task<bool> DeleteMovie(int id)
        {
            var movie = await _context.Movies.FindAsync(id);
            if (movie == null) return false;

            _context.Movies.Remove(movie);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
