﻿using Book.Data;
using Book.Data.DB;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class BookingService
    {
        private readonly BookMyShowDbContext _context;

        public BookingService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<Booking> CreateBookingWithTickets(int userId, int showId, List<int> seatIds)
        {
            var show = await _context.Shows.FirstOrDefaultAsync(s => s.ShowId == showId);
            if (show == null)
                throw new InvalidOperationException($"Show with ID {showId} not found.");

            if (seatIds == null || !seatIds.Any())
                throw new ArgumentException("At least one seat must be selected.");

            var booking = new Booking
            {
                UserId = userId,
                MovieShowId = showId,
                NumberOfTickets = seatIds.Count,
                BookingDate = DateTime.UtcNow,
                Status = "Confirmed",
                TotalAmount = show.Price * seatIds.Count
            };

            _context.Bookings.Add(booking);
            await _context.SaveChangesAsync();

            foreach (var seatId in seatIds)
            {
                var seat = await _context.Seats.FindAsync(seatId);
                if (seat == null)
                    throw new InvalidOperationException($"Seat ID {seatId} not found.");

                if (seat.Status == "Booked")
                    throw new InvalidOperationException($"Seat ID {seatId} is already booked.");

                seat.Status = "Booked";

                var ticket = new Ticket
                {
                    BookingId = booking.BookingId,
                    SeatId = seat.SeatId
                };

                _context.Tickets.Add(ticket);
            }

            await _context.SaveChangesAsync();
            return booking;
        }

        public async Task<IEnumerable<Booking>> GetAllBooking() =>
            await _context.Bookings.ToListAsync();

        public async Task<IEnumerable<Booking>> GetBookingsByUserId(int userId) =>
            await _context.Bookings
                .Where(b => b.UserId == userId)
                .ToListAsync();

        public async Task UpdateBooking(int bookingId, string status)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking == null) return;

            booking.Status = status;
            await _context.SaveChangesAsync();
        }

        public async Task Reschedule(int bookingId, DateTime newDate)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking == null) return;

            booking.NewDate = newDate;
            await _context.SaveChangesAsync();
        }

        public async Task<bool> DeleteBooking(int bookingId)
        {
            var booking = await _context.Bookings.FindAsync(bookingId);
            if (booking == null) return false;

            _context.Bookings.Remove(booking);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
