﻿using Book.Data; // For the Theatre entity
using Book.Data.DB; // For BookMyShowDbContext
using Book.DTO; // For TheatreDTO, TheatreCreateDTO, TheatreUpdateDTO
using Microsoft.EntityFrameworkCore; // For ToListAsync, FindAsync, etc.
using System.Collections.Generic; // For List<T>
using System.Linq; // For .Select(), .Where(), .OrderBy(), .AnyAsync()
using System.Threading.Tasks; // For async/await
using System; // For ArgumentException, InvalidOperationException

namespace Book.Services
{
    public class TheatreService
    {
        private readonly BookMyShowDbContext _context; // Inject DbContext

        public TheatreService(BookMyShowDbContext context)
        {
            _context = context;
        }

        // List all theatres
        public async Task<List<TheatreDTO>> GetAllTheatres()
        {
            return await _context.Theatres
                                 .Select(t => new TheatreDTO
                                 {
                                     TheatreId = t.TheatreId,
                                     TheatreName = t.TheatreName,
                                     Location = t.Location,
                                     Address = t.Address,
                                     CityId = t.CityId,
                                     Capacity = t.Capacity,
                                     ScreenCount = t.ScreenCount
                                 })
                                 .ToListAsync();
        }

        // Get theatre by ID
        public async Task<TheatreDTO?> GetTheatreById(int id)
        {
            var theatre = await _context.Theatres.FindAsync(id);

            if (theatre == null)
            {
                return null; // Return null if not found
            }

            return new TheatreDTO
            {
                TheatreId = theatre.TheatreId,
                TheatreName = theatre.TheatreName,
                Location = theatre.Location,
                Address = theatre.Address,
                CityId = theatre.CityId,
                Capacity = theatre.Capacity,
                ScreenCount = theatre.ScreenCount
            };
        }

        // Get theatres by City ID
        public async Task<List<TheatreDTO>> GetTheatresByCityId(int cityId)
        {
            return await _context.Theatres
                                 .Where(t => t.CityId == cityId)
                                 .OrderBy(t => t.TheatreName)
                                 .Select(t => new TheatreDTO
                                 {
                                     TheatreId = t.TheatreId,
                                     TheatreName = t.TheatreName,
                                     Location = t.Location,
                                     Address = t.Address,
                                     CityId = t.CityId,
                                     Capacity = t.Capacity,
                                     ScreenCount = t.ScreenCount
                                 })
                                 .ToListAsync();
        }

        // Create Theatre
        public async Task<TheatreDTO?> CreateTheatre(TheatreDTO theatreCreate) // Corrected parameter type
        {
            // Input validation
            if (string.IsNullOrWhiteSpace(theatreCreate.TheatreName))
            {
                throw new ArgumentException("TheatreName cannot be empty.", nameof(theatreCreate.TheatreName));
            }
            if (string.IsNullOrWhiteSpace(theatreCreate.Location))
            {
                throw new ArgumentException("Location cannot be empty.", nameof(theatreCreate.Location));
            }
            if (string.IsNullOrWhiteSpace(theatreCreate.Address))
            {
                throw new ArgumentException("Address cannot be empty.", nameof(theatreCreate.Address));
            }
            if (theatreCreate.CityId <= 0)
            {
                throw new ArgumentException("Invalid CityId.", nameof(theatreCreate.CityId));
            }
            if (theatreCreate.Capacity < 0)
            {
                throw new ArgumentException("Capacity cannot be negative.", nameof(theatreCreate.Capacity));
            }
            if (theatreCreate.ScreenCount < 0)
            {
                throw new ArgumentException("ScreenCount cannot be negative.", nameof(theatreCreate.ScreenCount));
            }

            // Check if City exists
            var cityExists = await _context.Cities.AnyAsync(c => c.CityId == theatreCreate.CityId);
            if (!cityExists)
            {
                throw new InvalidOperationException($"City with ID {theatreCreate.CityId} not found.");
            }

            // Prevent duplicate theatres with the same name, city, and location
            var existingTheatre = await _context.Theatres
                                                .AnyAsync(t => t.TheatreName == theatreCreate.TheatreName &&
                                                               t.CityId == theatreCreate.CityId &&
                                                               t.Location == theatreCreate.Location);
            if (existingTheatre)
            {
                throw new InvalidOperationException($"A theatre with the name '{theatreCreate.TheatreName}' already exists in this city and location.");
            }

            var theatre = new Theatre
            {
                TheatreName = theatreCreate.TheatreName,
                Location = theatreCreate.Location,
                Address = theatreCreate.Address,
                CityId = theatreCreate.CityId,
                Capacity = theatreCreate.Capacity,
                ScreenCount = theatreCreate.ScreenCount
            };

            _context.Theatres.Add(theatre);
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new TheatreDTO
                {
                    TheatreId = theatre.TheatreId,
                    TheatreName = theatre.TheatreName,
                    Location = theatre.Location,
                    Address = theatre.Address,
                    CityId = theatre.CityId,
                    Capacity = theatre.Capacity,
                    ScreenCount = theatre.ScreenCount
                };
            }
            return null;
        }

        // Update Theatre
        public async Task<TheatreDTO?> UpdateTheatre(int id, TheatreDTO theatreUpdate) // Corrected parameter type
        {
            var existingTheatre = await _context.Theatres.FindAsync(id);

            if (existingTheatre == null)
            {
                return null; // Theatre not found
            }

            // Input validation for update
            if (string.IsNullOrWhiteSpace(theatreUpdate.TheatreName))
            {
                throw new ArgumentException("TheatreName cannot be empty for update.", nameof(theatreUpdate.TheatreName));
            }
            if (string.IsNullOrWhiteSpace(theatreUpdate.Location))
            {
                throw new ArgumentException("Location cannot be empty for update.", nameof(theatreUpdate.Location));
            }
            if (string.IsNullOrWhiteSpace(theatreUpdate.Address))
            {
                throw new ArgumentException("Address cannot be empty for update.", nameof(theatreUpdate.Address));
            }
            if (theatreUpdate.CityId <= 0)
            {
                throw new ArgumentException("Invalid CityId for update.", nameof(theatreUpdate.CityId));
            }
            if (theatreUpdate.Capacity < 0)
            {
                throw new ArgumentException("Capacity cannot be negative for update.", nameof(theatreUpdate.Capacity));
            }
            if (theatreUpdate.ScreenCount < 0)
            {
                throw new ArgumentException("ScreenCount cannot be negative for update.", nameof(theatreUpdate.ScreenCount));
            }

            // Check if City exists if CityId is being changed
            if (existingTheatre.CityId != theatreUpdate.CityId)
            {
                var cityExists = await _context.Cities.AnyAsync(c => c.CityId == theatreUpdate.CityId);
                if (!cityExists)
                {
                    throw new InvalidOperationException($"City with ID {theatreUpdate.CityId} not found for update.");
                }
            }

            // Prevent changing to a duplicate theatre (same name, city, location, excluding itself)
            var duplicateTheatre = await _context.Theatres
                                                 .AnyAsync(t => t.TheatreName == theatreUpdate.TheatreName &&
                                                                t.CityId == theatreUpdate.CityId &&
                                                                t.Location == theatreUpdate.Location &&
                                                                t.TheatreId != id); // Exclude the current theatre
            if (duplicateTheatre)
            {
                throw new InvalidOperationException($"Another theatre with the name '{theatreUpdate.TheatreName}' already exists in this city and location.");
            }

            existingTheatre.TheatreName = theatreUpdate.TheatreName;
            existingTheatre.Location = theatreUpdate.Location;
            existingTheatre.Address = theatreUpdate.Address;
            existingTheatre.CityId = theatreUpdate.CityId;
            existingTheatre.Capacity = theatreUpdate.Capacity;
            existingTheatre.ScreenCount = theatreUpdate.ScreenCount;

            _context.Entry(existingTheatre).State = EntityState.Modified;
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new TheatreDTO
                {
                    TheatreId = existingTheatre.TheatreId,
                    TheatreName = existingTheatre.TheatreName,
                    Location = existingTheatre.Location,
                    Address = existingTheatre.Address,
                    CityId = existingTheatre.CityId,
                    Capacity = existingTheatre.Capacity,
                    ScreenCount = existingTheatre.ScreenCount
                };
            }
            return null;
        }

        // Delete Theatre
        public async Task<bool> DeleteTheatre(int id)
        {
            var theatreToDelete = await _context.Theatres.FindAsync(id);

            if (theatreToDelete == null)
            {
                return false; // Theatre not found
            }

            // Check for dependent entities (Shows, Seats) before deleting
            var hasShows = await _context.Shows.AnyAsync(s => s.TheatreId == id);
            if (hasShows)
            {
                throw new InvalidOperationException($"Cannot delete Theatre {id} as it has associated shows. Delete shows first.");
            }

            var hasSeats = await _context.Seats.AnyAsync(s => s.TheatreId == id);
            if (hasSeats)
            {
                throw new InvalidOperationException($"Cannot delete Theatre {id} as it has associated seats. Delete seats first.");
            }

            _context.Theatres.Remove(theatreToDelete);
            int savedChanges = await _context.SaveChangesAsync();

            return savedChanges > 0;
        }
    }
}