﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class SeatService
    {
        private readonly BookMyShowDbContext _context;

        public SeatService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<SeatDTO>> GetAllSeats() =>
            await _context.Seats
                .Select(s => new SeatDTO
                {
                    SeatId = s.SeatId,
                    SeatNumber = s.SeatNumber,
                    Row = s.Row,
                    Type = s.Type,
                    Status = s.Status,
                    TheatreId = s.TheatreId
                })
                .ToListAsync();

        public async Task<SeatDTO?> GetSeatById(int id)
        {
            var seat = await _context.Seats.FindAsync(id);
            return seat == null ? null : new SeatDTO
            {
                SeatId = seat.SeatId,
                SeatNumber = seat.SeatNumber,
                Row = seat.Row,
                Type = seat.Type,
                Status = seat.Status,
                TheatreId = seat.TheatreId
            };
        }

        public async Task<List<SeatDTO>> GetSeatsByTheatreId(int theatreId) =>
            await _context.Seats
                .Where(s => s.TheatreId == theatreId)
                .Select(s => new SeatDTO
                {
                    SeatId = s.SeatId,
                    SeatNumber = s.SeatNumber,
                    Row = s.Row,
                    Type = s.Type,
                    Status = s.Status,
                    TheatreId = s.TheatreId
                })
                .ToListAsync();

        public async Task<SeatDTO?> CreateSeat(SeatDTO dto)
        {
            if (string.IsNullOrWhiteSpace(dto.SeatNumber.ToString()) ||
                string.IsNullOrWhiteSpace(dto.Row.ToString()) ||
                dto.TheatreId <= 0)
                throw new ArgumentException("Invalid seat input.");

            var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == dto.TheatreId);
            if (!theatreExists)
                throw new ArgumentException($"Theatre with ID {dto.TheatreId} does not exist.");

            var duplicate = await _context.Seats.AnyAsync(s =>
                s.TheatreId == dto.TheatreId &&
                s.SeatNumber == dto.SeatNumber &&
                s.Row == dto.Row);
            if (duplicate)
                throw new InvalidOperationException($"Seat {dto.SeatNumber} in row {dto.Row} already exists.");

            var seat = new Seat
            {
                SeatNumber = dto.SeatNumber,
                Row = dto.Row,
                Type = dto.Type,
                Status = dto.Status,
                TheatreId = dto.TheatreId
            };

            _context.Seats.Add(seat);
            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new SeatDTO
            {
                SeatId = seat.SeatId,
                SeatNumber = seat.SeatNumber,
                Row = seat.Row,
                Type = seat.Type,
                Status = seat.Status,
                TheatreId = seat.TheatreId
            } : null;
        }

        public async Task<SeatDTO?> UpdateSeat(int id, SeatDTO dto)
        {
            var existing = await _context.Seats.FindAsync(id);
            if (existing == null) return null;

            if (string.IsNullOrWhiteSpace(dto.SeatNumber.ToString()) ||
                string.IsNullOrWhiteSpace(dto.Row.ToString()) ||
                dto.TheatreId <= 0)
                throw new ArgumentException("Invalid seat input.");

            if (existing.TheatreId != dto.TheatreId)
            {
                var theatreExists = await _context.Theatres.AnyAsync(t => t.TheatreId == dto.TheatreId);
                if (!theatreExists)
                    throw new ArgumentException($"Theatre with ID {dto.TheatreId} does not exist.");
            }

            var duplicate = await _context.Seats.AnyAsync(s =>
                s.SeatId != id &&
                s.TheatreId == dto.TheatreId &&
                s.SeatNumber == dto.SeatNumber &&
                s.Row == dto.Row);
            if (duplicate)
                throw new InvalidOperationException($"Seat {dto.SeatNumber} in row {dto.Row} already exists.");

            existing.SeatNumber = dto.SeatNumber;
            existing.Row = dto.Row;
            existing.Type = dto.Type;
            existing.Status = dto.Status;
            existing.TheatreId = dto.TheatreId;

            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new SeatDTO
            {
                SeatId = existing.SeatId,
                SeatNumber = existing.SeatNumber,
                Row = existing.Row,
                Type = existing.Type,
                Status = existing.Status,
                TheatreId = existing.TheatreId
            } : null;
        }

        public async Task<bool> DeleteSeat(int id)
        {
            var seat = await _context.Seats.FindAsync(id);
            if (seat == null) return false;

            _context.Seats.Remove(seat);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
