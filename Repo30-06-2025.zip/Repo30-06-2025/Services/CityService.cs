﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class CityService
    {
        private readonly BookMyShowDbContext _context;

        public CityService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<CityDTO>> GetAllCities() =>
            await _context.Cities
                .Select(c => new CityDTO
                {
                    CityId = c.CityId,
                    CityName = c.CityName,
                    State = c.State,
                    Country = c.Country
                })
                .ToListAsync();

        public async Task<CityDTO?> GetCityById(int id)
        {
            var city = await _context.Cities.FindAsync(id);
            return city == null ? null : new CityDTO
            {
                CityId = city.CityId,
                CityName = city.CityName,
                State = city.State,
                Country = city.Country
            };
        }

        public async Task<CityDTO?> AddCity(CityDTO cityCreate)
        {
            if (string.IsNullOrWhiteSpace(cityCreate.CityName))
                throw new ArgumentException("City name cannot be empty.", nameof(cityCreate.CityName));

            if (await _context.Cities.AnyAsync(c => c.CityName == cityCreate.CityName))
                throw new InvalidOperationException($"City with name '{cityCreate.CityName}' already exists.");

            var city = new City
            {
                CityName = cityCreate.CityName,
                State = cityCreate.State,
                Country = cityCreate.Country
            };

            _context.Cities.Add(city);
            var saved = await _context.SaveChangesAsync();

            return saved > 0
                ? new CityDTO
                {
                    CityId = city.CityId,
                    CityName = city.CityName,
                    State = city.State,
                    Country = city.Country
                }
                : null;
        }

        public async Task<CityDTO?> UpdateCity(int id, CityDTO cityUpdate)
        {
            var existingCity = await _context.Cities.FindAsync(id);
            if (existingCity == null) return null;

            if (string.IsNullOrWhiteSpace(cityUpdate.CityName))
                throw new ArgumentException("City name cannot be empty.", nameof(cityUpdate.CityName));

            if (existingCity.CityName != cityUpdate.CityName &&
                await _context.Cities.AnyAsync(c => c.CityName == cityUpdate.CityName && c.CityId != id))
                throw new InvalidOperationException($"City name '{cityUpdate.CityName}' is already taken.");

            existingCity.CityName = cityUpdate.CityName;
            existingCity.State = cityUpdate.State;
            existingCity.Country = cityUpdate.Country;

            var saved = await _context.SaveChangesAsync();

            return saved > 0
                ? new CityDTO
                {
                    CityId = existingCity.CityId,
                    CityName = existingCity.CityName,
                    State = existingCity.State,
                    Country = existingCity.Country
                }
                : null;
        }

        public async Task<bool> DeleteCity(int id)
        {
            var cityToDelete = await _context.Cities.FindAsync(id);
            if (cityToDelete == null) return false;

            _context.Cities.Remove(cityToDelete);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
