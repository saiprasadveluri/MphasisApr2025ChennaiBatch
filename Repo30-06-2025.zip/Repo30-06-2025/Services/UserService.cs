﻿using Book.Data; 
using Book.Data.DB; 
using Book.DTO; 
using Microsoft.AspNetCore.Identity; 
using Microsoft.EntityFrameworkCore; 


namespace Book.Services
{
    public class UserService
    {
        private readonly BookMyShowDbContext _context;
        private readonly IPasswordHasher<User> _passwordHasher; 

        public UserService(BookMyShowDbContext context, IPasswordHasher<User> passwordHasher)
        {
            _context = context;
            _passwordHasher = passwordHasher;
        }

        public async Task<List<UserDTO>> GetAllUsers()
        {
            return await _context.Users 
                                 .Select(u => new UserDTO
                                 {
                                     UserId = u.UserId,
                                     UserName = u.UserName,
                                     UserEmail = u.UserEmail,
                                     Age = u.Age,
                                     Gender = u.Gender,
                                     MobileNo = u.MobileNo,
                                     Address = u.Address
                                 })
                                 .ToListAsync();
        }

     
        public async Task<UserDTO?> GetUserById(int id) 
        {
            var user = await _context.Users.FindAsync(id); 

            if (user == null)
            {
                return null; 
            }

            return new UserDTO
            {
                UserId = user.UserId,
                UserName = user.UserName,
                UserEmail = user.UserEmail,
                Age = user.Age,
                Gender = user.Gender,
                MobileNo = user.MobileNo,
                Address = user.Address
            };
        }

        public async Task<UserDTO?> GetUserByEmail(string email) 
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return null; 
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserEmail == email); 

            if (user == null)
            {
                return null; 
            }

            return new UserDTO
            {
                UserId = user.UserId,
                UserName = user.UserName,
                UserEmail = user.UserEmail,
                Age = user.Age,
                Gender = user.Gender,
                MobileNo = user.MobileNo,
                Address = user.Address
            };
        }

        public async Task<UserDTO?> CreateUser(UserDTO userCreateDto) 
        {
            if (string.IsNullOrWhiteSpace(userCreateDto.UserName))
            {
                throw new ArgumentException("User name cannot be empty or whitespace.", nameof(userCreateDto.UserName));
            }
            if (string.IsNullOrWhiteSpace(userCreateDto.UserEmail))
            {
                throw new ArgumentException("User email cannot be empty or whitespace.", nameof(userCreateDto.UserEmail));
            }
            if (string.IsNullOrWhiteSpace(userCreateDto.Password) || userCreateDto.Password.Length < 6)
            {
                throw new ArgumentException("Password must be at least 6 characters long.", nameof(userCreateDto.Password));
            }
            if (userCreateDto.Age < 0 || userCreateDto.Age > 150)
            {
                throw new ArgumentException("Invalid Age.", nameof(userCreateDto.Age));
            }

            var existingUserByEmail = await _context.Users.AnyAsync(u => u.UserEmail == userCreateDto.UserEmail); 
            if (existingUserByEmail)
            {
                throw new InvalidOperationException($"User with email '{userCreateDto.UserEmail}' already exists.");
            }

            string hashedPassword = _passwordHasher.HashPassword(new User(), userCreateDto.Password);

            var newUser = new User 
            {
                UserName = userCreateDto.UserName,
                UserEmail = userCreateDto.UserEmail,
                Password = hashedPassword, 
                Age = userCreateDto.Age,
                Gender = userCreateDto.Gender,
                MobileNo = userCreateDto.MobileNo,
                Address = userCreateDto.Address
            };

            _context.Users.Add(newUser); 
            int savedChanges = await _context.SaveChangesAsync(); 

            if (savedChanges > 0)
            {
                return new UserDTO
                {
                    UserId = newUser.UserId,
                    UserName = newUser.UserName,
                    UserEmail = newUser.UserEmail,
                    Age = newUser.Age,
                    Gender = newUser.Gender,
                    MobileNo = newUser.MobileNo,
                    Address = newUser.Address
                };
            }
            return null; 
        }

        public async Task<UserDTO?> UpdateUser(int id, UserDTO userUpdateDto) 
        {
            var existingUser = await _context.Users.FindAsync(id);

            if (existingUser == null)
            {
                return null; 
            }

            if (string.IsNullOrWhiteSpace(userUpdateDto.UserName))
            {
                throw new ArgumentException("User name cannot be empty or whitespace for update.", nameof(userUpdateDto.UserName));
            }
            if (string.IsNullOrWhiteSpace(userUpdateDto.UserEmail))
            {
                throw new ArgumentException("User email cannot be empty or whitespace for update.", nameof(userUpdateDto.UserEmail));
            }
            if (userUpdateDto.Age < 0 || userUpdateDto.Age > 150)
            {
                throw new ArgumentException("Invalid Age for update.", nameof(userUpdateDto.Age));
            }

            if (existingUser.UserEmail != userUpdateDto.UserEmail)
            {
                var emailTaken = await _context.Users.AnyAsync(u => u.UserEmail == userUpdateDto.UserEmail && u.UserId != id); // Use _context
                if (emailTaken)
                {
                    throw new InvalidOperationException($"Email '{userUpdateDto.UserEmail}' is already taken by another user.");
                }
            }

            existingUser.UserName = userUpdateDto.UserName;
            existingUser.UserEmail = userUpdateDto.UserEmail;
            existingUser.Age = userUpdateDto.Age;
            existingUser.Gender = userUpdateDto.Gender;
            existingUser.MobileNo = userUpdateDto.MobileNo;
            existingUser.Address = userUpdateDto.Address;

            _context.Entry(existingUser).State = EntityState.Modified; 
            int savedChanges = await _context.SaveChangesAsync();

            if (savedChanges > 0)
            {
                return new UserDTO
                {
                    UserId = existingUser.UserId,
                    UserName = existingUser.UserName,
                    UserEmail = existingUser.UserEmail,
                    Age = existingUser.Age,
                    Gender = existingUser.Gender,
                    MobileNo = existingUser.MobileNo,
                    Address = existingUser.Address
                };
            }
            return null; 
        }

        public async Task<bool> DeleteUser(int id)
        {
            var userToDelete = await _context.Users.FindAsync(id); 

            if (userToDelete == null)
            {
                return false;
            }

            _context.Users.Remove(userToDelete); 
            int savedChanges = await _context.SaveChangesAsync(); 

            return savedChanges > 0; 
        }

        public async Task<bool> ChangePassword(int userId, ChangePasswordDTO changePasswordDto)
        {
            var user = await _context.Users.FindAsync(userId); 

            if (user == null)
            {
                return false; 
            }

            var verificationResult = _passwordHasher.VerifyHashedPassword(user, user.Password, changePasswordDto.CurrentPassword);

            if (verificationResult == PasswordVerificationResult.Failed)
            {
                throw new UnauthorizedAccessException("The current password provided is incorrect.");
            }

            if (string.IsNullOrWhiteSpace(changePasswordDto.NewPassword) || changePasswordDto.NewPassword.Length < 6)
            {
                throw new ArgumentException("New password must be at least 6 characters long.", nameof(changePasswordDto.NewPassword));
            }

            if (changePasswordDto.NewPassword.Equals(changePasswordDto.CurrentPassword, StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("New password cannot be the same as the current password.");
            }

            user.Password = _passwordHasher.HashPassword(user, changePasswordDto.NewPassword);

            _context.Entry(user).State = EntityState.Modified; 
            int savedChanges = await _context.SaveChangesAsync(); 

            return savedChanges > 0;
        }

        public async Task<UserDTO?> VerifyUserCredentialsAsync(string email, string plainTextPassword) 
        {
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(plainTextPassword))
            {
                return null;
            }

            var user = await _context.Users.FirstOrDefaultAsync(u => u.UserEmail == email); 

            if (user == null)
            {
                return null; 
            }

            var verificationResult = _passwordHasher.VerifyHashedPassword(user, user.Password, plainTextPassword);

            if (verificationResult == PasswordVerificationResult.Success ||
                verificationResult == PasswordVerificationResult.SuccessRehashNeeded)
            {
                if (verificationResult == PasswordVerificationResult.SuccessRehashNeeded)
                {
                   
                    user.Password = _passwordHasher.HashPassword(user, plainTextPassword);
                    await _context.SaveChangesAsync();
                }

                return new UserDTO
                {
                    UserId = user.UserId,
                    UserName = user.UserName,
                    UserEmail = user.UserEmail,
                    Age = user.Age,
                    Gender = user.Gender,
                    MobileNo = user.MobileNo,
                    Address = user.Address
                };
            }
            return null; 
        }
    }
}