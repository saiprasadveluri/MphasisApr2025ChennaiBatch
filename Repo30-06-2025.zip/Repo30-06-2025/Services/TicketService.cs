﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class TicketService
    {
        private readonly BookMyShowDbContext _context;

        public TicketService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<TicketDTO>> GetAllTickets() =>
            await _context.Tickets
                .Select(t => new TicketDTO
                {
                    TicketId = t.TicketId,
                    BookingId = t.BookingId,
                    SeatId = t.SeatId
                })
                .ToListAsync();

        public async Task<TicketDTO?> GetTicketById(int id)
        {
            var ticket = await _context.Tickets.FindAsync(id);
            return ticket == null ? null : new TicketDTO
            {
                TicketId = ticket.TicketId,
                BookingId = ticket.BookingId,
                SeatId = ticket.SeatId
            };
        }

        public async Task<List<TicketDTO>> GetTicketsByBookingId(int bookingId) =>
            await _context.Tickets
                .Where(t => t.BookingId == bookingId)
                .Select(t => new TicketDTO
                {
                    TicketId = t.TicketId,
                    BookingId = t.BookingId,
                    SeatId = t.SeatId
                })
                .ToListAsync();

        public async Task<TicketDTO?> CreateTicket(int bookingId, int seatId)
        {
            if (bookingId <= 0 || seatId <= 0)
                throw new ArgumentException("Invalid BookingId or SeatId.");

            var bookingExists = await _context.Bookings.AnyAsync(b => b.BookingId == bookingId);
            if (!bookingExists)
                throw new InvalidOperationException($"Booking ID {bookingId} not found.");

            var seatExists = await _context.Seats.AnyAsync(s => s.SeatId == seatId);
            if (!seatExists)
                throw new InvalidOperationException($"Seat ID {seatId} not found.");

            var isTaken = await _context.Tickets.AnyAsync(t => t.BookingId == bookingId && t.SeatId == seatId);
            if (isTaken)
                throw new InvalidOperationException($"Seat ID {seatId} is already ticketed for Booking ID {bookingId}.");

            var ticket = new Ticket
            {
                BookingId = bookingId,
                SeatId = seatId
            };

            _context.Tickets.Add(ticket);
            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new TicketDTO
            {
                TicketId = ticket.TicketId,
                BookingId = ticket.BookingId,
                SeatId = ticket.SeatId
            } : null;
        }

        public async Task<TicketDTO?> UpdateTicket(int id, TicketDTO dto)
        {
            var ticket = await _context.Tickets.FindAsync(id);
            if (ticket == null) return null;

            if (dto.BookingId <= 0 || dto.SeatId <= 0)
                throw new ArgumentException("Invalid BookingId or SeatId.");

            if (ticket.BookingId != dto.BookingId)
            {
                var bookingExists = await _context.Bookings.AnyAsync(b => b.BookingId == dto.BookingId);
                if (!bookingExists)
                    throw new InvalidOperationException($"Booking ID {dto.BookingId} not found.");
            }

            if (ticket.SeatId != dto.SeatId)
            {
                var seatExists = await _context.Seats.AnyAsync(s => s.SeatId == dto.SeatId);
                if (!seatExists)
                    throw new InvalidOperationException($"Seat ID {dto.SeatId} not found.");

                var isTaken = await _context.Tickets.AnyAsync(t =>
                    t.BookingId == dto.BookingId &&
                    t.SeatId == dto.SeatId &&
                    t.TicketId != id);
                if (isTaken)
                    throw new InvalidOperationException($"Seat ID {dto.SeatId} is already ticketed in Booking ID {dto.BookingId}.");
            }

            ticket.BookingId = dto.BookingId;
            ticket.SeatId = dto.SeatId;

            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new TicketDTO
            {
                TicketId = ticket.TicketId,
                BookingId = ticket.BookingId,
                SeatId = ticket.SeatId
            } : null;
        }

        public async Task<bool> DeleteTicket(int id)
        {
            var ticket = await _context.Tickets.FindAsync(id);
            if (ticket == null) return false;

            _context.Tickets.Remove(ticket);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
