﻿using Book.Data;
using Book.Data.DB;
using Book.DTO;
using Microsoft.EntityFrameworkCore;

namespace Book.Services
{
    public class ReviewService
    {
        private readonly BookMyShowDbContext _context;

        public ReviewService(BookMyShowDbContext context)
        {
            _context = context;
        }

        public async Task<List<ReviewDTO>> GetAllReviews() =>
            await _context.Reviews
                .Select(r => new ReviewDTO
                {
                    CommentId = r.CommentId,
                    Rating = r.Rating,
                    CommentText = r.CommentText,
                    DatePosted = r.DatePosted,
                    UserId = r.UserId,
                    MovieId = r.MovieId,
                    //Timings = r.Timings
                })
                .ToListAsync();

        public async Task<ReviewDTO?> GetReviewById(int id)
        {
            var review = await _context.Reviews.FindAsync(id);
            return review == null ? null : new ReviewDTO
            {
                CommentId = review.CommentId,
                Rating = review.Rating,
                CommentText = review.CommentText,
                DatePosted = review.DatePosted,
                UserId = review.UserId,
                MovieId = review.MovieId,
               // Timings = review.Timings
            };
        }

        public async Task<List<ReviewDTO>> GetReviewsByMovieId(int movieId) =>
            await _context.Reviews
                .Where(r => r.MovieId == movieId)
                .Select(r => new ReviewDTO
                {
                    CommentId = r.CommentId,
                    Rating = r.Rating,
                    CommentText = r.CommentText,
                    DatePosted = r.DatePosted,
                    UserId = r.UserId,
                    MovieId = r.MovieId,
                   // Timings = r.Timings
                })
                .ToListAsync();

        public async Task<ReviewDTO?> CreateReview(ReviewDTO dto)
        {
            if (dto.Rating < 1 || dto.Rating > 5)
                throw new ArgumentException("Rating must be between 1 and 5.", nameof(dto.Rating));

            if (dto.UserId <= 0 || dto.MovieId <= 0)
                throw new ArgumentException("Invalid UserId or MovieId.");

            var userExists = await _context.Users.AnyAsync(u => u.UserId == dto.UserId);
            var movieExists = await _context.Movies.AnyAsync(m => m.MovieId == dto.MovieId);
            if (!userExists || !movieExists)
                throw new ArgumentException("User or Movie does not exist.");

            var review = new Review
            {
                Rating = (int)dto.Rating,
                CommentText = dto.CommentText,
                DatePosted = DateTime.UtcNow,
                UserId = dto.UserId,
                MovieId = dto.MovieId,
                //Timings = dto.Timings
            };

            _context.Reviews.Add(review);
            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new ReviewDTO
            {
                CommentId = review.CommentId,
                Rating = review.Rating,
                CommentText = review.CommentText,
                DatePosted = review.DatePosted,
                UserId = review.UserId,
                MovieId = review.MovieId,
               // Timings = review.Timings
            } : null;
        }

        public async Task<ReviewDTO?> UpdateReview(int id, ReviewDTO dto)
        {
            var review = await _context.Reviews.FindAsync(id);
            if (review == null) return null;

            if (dto.Rating < 1 || dto.Rating > 5)
                throw new ArgumentException("Rating must be between 1 and 5.", nameof(dto.Rating));

            review.Rating = (int)dto.Rating;
            review.CommentText = dto.CommentText;
            //review.Timings = dto.Timings;

            var saved = await _context.SaveChangesAsync();

            return saved > 0 ? new ReviewDTO
            {
                CommentId = review.CommentId,
                Rating = review.Rating,
                CommentText = review.CommentText,
                DatePosted = review.DatePosted,
                UserId = review.UserId,
                MovieId = review.MovieId,
                //Timings = review.Timings
            } : null;
        }

        public async Task<bool> DeleteReview(int id)
        {
            var review = await _context.Reviews.FindAsync(id);
            if (review == null) return false;

            _context.Reviews.Remove(review);
            return await _context.SaveChangesAsync() > 0;
        }
    }
}
