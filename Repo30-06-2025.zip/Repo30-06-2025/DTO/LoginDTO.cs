﻿namespace Book.DTO
{
    public class LoginDTO
    {
        public string UserEmail { get; set; }
        public string Password { get; set; }
    }
}
