﻿using Book.Data;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Book.DTO
{
    public class BookingDTO
    {
        public int BookingId { get; set; }
        public DateTime BookingDate { get; set; }
        public int NumberOfTickets { get; set; }
        public string Status { get; set; } = string.Empty;
        public long TotalAmount { get; set; }
        public int UserId { get; set; }
        public int ShowId { get; set; }
        public DateTime? NewDate { get; set; }
    }

    public class BookingCreateDTO
    {
        public int UserId { get; set; }
        public int ShowId { get; set; }
        public int NumberOfTickets { get; set; }
        public long TotalAmount { get; set; }
        public DateTime BookingDate { get; set; }
        public string Status { get; set; } = "Confirmed";
    }
    public class BookingStatusUpdateDTO
    {
        public string Status { get; set; } = string.Empty;
    }

    public class BookingRescheduleDTO
    {
        public DateTime NewDate { get; set; }
    }

    public class BookingWithSeatsDTO
    {
        public int UserId { get; set; }
        public int ShowId { get; set; }
        public List<int> SeatIds { get; set; }
    }

}


