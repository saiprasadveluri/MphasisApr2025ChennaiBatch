using Book.Data.DB;
using Book.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Configure services
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

builder.Services.AddDbContext<BookMyShowDbContext>(options =>
    options.UseSqlServer(connectionString));

// Register password hashers for User and Admin
builder.Services.AddScoped<IPasswordHasher<Book.Data.User>, PasswordHasher<Book.Data.User>>();
builder.Services.AddScoped<IPasswordHasher<Book.Data.Admin>, PasswordHasher<Book.Data.Admin>>();

// Register application services
builder.Services.AddScoped<AdminService>();
builder.Services.AddScoped<BookingService>();
builder.Services.AddScoped<CityService>();
builder.Services.AddScoped<GenreService>();
builder.Services.AddScoped<LanguageService>();
builder.Services.AddScoped<MovieService>();
builder.Services.AddScoped<MovieShowService>();
builder.Services.AddScoped<ReviewService>();
builder.Services.AddScoped<SeatService>();
builder.Services.AddScoped<ShowService>();
builder.Services.AddScoped<TheatreService>();
builder.Services.AddScoped<TicketService>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<Unity>(); // Register Unity service aggregator if you're using it

var app = builder.Build();

// Configure middleware
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();
