﻿using Book.Data;
using System.ComponentModel.DataAnnotations;

public class Booking
{
    [Key]
    public int BookingId { get; set; }

    [Required]
    public DateTime BookingDate { get; set; }

    [Required]
    public int NumberOfTickets { get; set; }

    [Required]
    [StringLength(20)]
    public string Status { get; set; }

    [Required]
    public long TotalAmount { get; set; }

    [Required]
    public int UserId { get; set; }
    public virtual User UserData { get; set; }

    [Required]
    public int MovieShowId { get; set; }
    public virtual MovieShow MovieShowData { get; set; }

    // Optional for rescheduling; make nullable
    public DateTime? NewDate { get; set; }

    public virtual ICollection<Ticket> Tickets { get; set; } = new List<Ticket>();
}
