﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Book.Data
{
    public class Theatre
    {
        [Key]
        public int TheatreId { get; set; }

        [Required]
        [StringLength(255)] // Added length constraint
        public string TheatreName { get; set; }

        [Required]
        [StringLength(255)] // Added length constraint
        public string Location { get; set; } // E.g., "Phoenix Marketcity"

        [Required]
        [StringLength(500)] // Added length constraint
        public string Address { get; set; }

        // Foreign Key to City
        [Required]
        public int CityId { get; set; }
        // Navigation property to City (assuming City entity exists)
        // If CityData is not guaranteed to be loaded or could be null
        // due to EF Core lazy loading or projection, you might consider 'virtual City? CityData { get; set; }'
        public virtual City CityData { get; set; }

        [Required]
        public int Capacity { get; set; } // Total seating capacity

        [Required]
        public int ScreenCount { get; set; } // Number of screens in the theatre

        // One-to-Many relationship with Show
        [InverseProperty("TheatreData")]
        public virtual ICollection<Show> Shows { get; set; } = new List<Show>();

        // One-to-Many relationship with Seat
        [InverseProperty("TheatreData")]
        public virtual ICollection<Seat> Seats { get; set; } = new List<Seat>();

        // One-to-Many relationship with MovieShow
        [InverseProperty("Theatre")]
        public virtual ICollection<MovieShow> MovieShows { get; set; } = new List<MovieShow>();

        // Removed: Bookings (moved to MovieShow)
    }
}